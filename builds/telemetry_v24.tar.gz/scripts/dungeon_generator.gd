class_name DungeonGenerator
extends RefCounted

const GameState = preload("res://scripts/game_state.gd")
const Enemy = preload("res://scripts/enemy.gd")

enum TileType {
	WALL,
	FLOOR,
	ENTRANCE,
	EXIT,
	CHEST,
	ALTAR
}

enum TemplateType {
	TEMPLATE_3,
	TEMPLATE_4,
	TEMPLATE_4L,
	TEMPLATE_5
}

class Room:
	var id: int
	var rect: Rect2i
	var center: Vector2i
	var role: String = ""       # "IN", "MID", "A", "B", "HUB", "OUT", "BR"
	var is_entrance: bool = false
	var is_exit: bool = false
	var is_hub: bool = false
	var is_branch: bool = false
	var is_secret: bool = false
	var connections: Array = []

	func _init(p_id: int, p_rect: Rect2i, p_role: String = "") -> void:
		id = p_id
		rect = p_rect
		role = p_role
		center = Vector2i(rect.position.x + rect.size.x / 2, rect.position.y + rect.size.y / 2)

var width: int = 32
var height: int = 16
var grid: Array = []
var rooms: Array = []
var entrance_pos: Vector2i = Vector2i.ZERO
var exit_pos: Vector2i = Vector2i.ZERO
var chests: Array[Vector2i] = []
var altars: Array[Vector2i] = []
var enemies: Array[Enemy] = []
var game_state: GameState = null

# Vestibule metadata for validation
var _vestibules: Array[Dictionary] = []

func _init(p_game_state: GameState) -> void:
	game_state = p_game_state

func generate_floor(floor_num: int) -> void:
	rooms.clear()
	chests.clear()
	altars.clear()
	enemies.clear()
	_vestibules.clear()

	grid.resize(width)
	for x in range(width):
		grid[x] = []
		grid[x].resize(height)
		for y in range(height):
			grid[x][y] = TileType.WALL

	var template: TemplateType = _get_template_for_floor(floor_num)
	var v_spine_min: int = 2
	var v_spine_max: int = 4
	var v_br_max: int = 3
	if template == TemplateType.TEMPLATE_4L or template == TemplateType.TEMPLATE_5:
		v_spine_max = 3

	# Roll vestibule lengths
	var spine_v_lengths: Array[int] = []
	var spine_edge_count: int = 2
	if template == TemplateType.TEMPLATE_4L or template == TemplateType.TEMPLATE_5:
		spine_edge_count = 3

	for e in range(spine_edge_count):
		spine_v_lengths.append(game_state.randi_range(v_spine_min, v_spine_max))

	var v_br: int = 0
	var has_branch: bool = (template == TemplateType.TEMPLATE_4 or template == TemplateType.TEMPLATE_5)
	if has_branch:
		v_br = game_state.randi_range(2, v_br_max)

	var y_hub: int = 2
	var x: int = 1

	var spine_roles: Array[String] = []
	match template:
		TemplateType.TEMPLATE_3: spine_roles = ["IN", "MID", "OUT"]
		TemplateType.TEMPLATE_4: spine_roles = ["IN", "HUB", "OUT"]
		TemplateType.TEMPLATE_4L: spine_roles = ["IN", "A", "B", "OUT"]
		TemplateType.TEMPLATE_5: spine_roles = ["IN", "A", "HUB", "OUT"]

	var hub_room: Room = null
	for i in range(spine_roles.size()):
		var r_role: String = spine_roles[i]
		var r_rect: Rect2i = Rect2i(x, y_hub, 5, 5)
		var room_obj: Room = Room.new(rooms.size(), r_rect, r_role)

		if r_role == "IN":
			room_obj.is_entrance = true
		elif r_role == "OUT":
			room_obj.is_exit = true
		elif r_role == "HUB":
			room_obj.is_hub = true
			hub_room = room_obj

		rooms.append(room_obj)

		if i < spine_roles.size() - 1:
			x = x + 5 + spine_v_lengths[i]
		else:
			x = x + 5

	var br_room: Room = null
	if has_branch and hub_room != null:
		var br_x: int = hub_room.rect.position.x
		var br_y: int = hub_room.rect.position.y + 5 + v_br
		if br_y + 5 > 15:
			push_error("CRITICAL ERROR: validate 12 floor=%d (BR out of bounds: br_y=%d)" % [floor_num, br_y])
			print("CRITICAL ERROR: validate 12 floor=%d (BR out of bounds: br_y=%d)" % [floor_num, br_y])
		br_room = Room.new(rooms.size(), Rect2i(br_x, br_y, 5, 5), "BR")
		br_room.is_branch = true
		br_room.is_secret = true
		rooms.append(br_room)

	# Carve rooms to grid
	for r in rooms:
		for rx in range(r.rect.position.x, r.rect.position.x + r.rect.size.x):
			for ry in range(r.rect.position.y, r.rect.position.y + r.rect.size.y):
				grid[rx][ry] = TileType.FLOOR

	# Carve straight spine vestibules
	for i in range(spine_roles.size() - 1):
		var r_left: Room = rooms[i]
		var r_right: Room = rooms[i + 1]
		var door_l: Vector2i = Vector2i(r_left.rect.position.x + 4, y_hub + 2)
		var door_r: Vector2i = Vector2i(r_right.rect.position.x, y_hub + 2)

		var v_cells: Array[Vector2i] = []
		for vx in range(r_left.rect.position.x + 5, r_right.rect.position.x):
			grid[vx][y_hub + 2] = TileType.FLOOR
			v_cells.append(Vector2i(vx, y_hub + 2))

		r_left.connections.append(r_right.id)
		r_right.connections.append(r_left)

		_vestibules.append({
			"from_id": r_left.id,
			"to_id": r_right.id,
			"is_branch": false,
			"length": v_cells.size(),
			"cells": v_cells,
			"door_from": door_l,
			"door_to": door_r
		})

	# Carve straight branch vestibule
	if has_branch and hub_room != null and br_room != null:
		var door_hub: Vector2i = Vector2i(hub_room.rect.position.x + 2, hub_room.rect.position.y + 4)
		var door_br: Vector2i = Vector2i(br_room.rect.position.x + 2, br_room.rect.position.y)

		var v_cells_br: Array[Vector2i] = []
		for vy in range(hub_room.rect.position.y + 5, br_room.rect.position.y):
			grid[hub_room.rect.position.x + 2][vy] = TileType.FLOOR
			v_cells_br.append(Vector2i(hub_room.rect.position.x + 2, vy))

		hub_room.connections.append(br_room.id)
		br_room.connections.append(hub_room.id)

		_vestibules.append({
			"from_id": hub_room.id,
			"to_id": br_room.id,
			"is_branch": true,
			"length": v_cells_br.size(),
			"cells": v_cells_br,
			"door_from": door_hub,
			"door_to": door_br
		})

	# Entrance & Exit placement
	var in_room: Room = rooms[0]
	entrance_pos = Vector2i(in_room.rect.position.x + 1, in_room.rect.position.y + 2)
	grid[entrance_pos.x][entrance_pos.y] = TileType.ENTRANCE

	var out_room: Room = null
	for r in rooms:
		if r.is_exit:
			out_room = r
			break
	exit_pos = Vector2i(out_room.rect.position.x + 3, out_room.rect.position.y + 2)
	grid[exit_pos.x][exit_pos.y] = TileType.EXIT

	# Rewards placement (Section 5)
	_place_rewards(floor_num, hub_room, br_room)

	# Enemies placement (Section 6)
	_place_enemies(floor_num)

	# Validation (Section 7)
	validate_or_die(floor_num)

func _get_template_for_floor(floor_num: int) -> TemplateType:
	match floor_num:
		1: return TemplateType.TEMPLATE_3
		2, 3, 4, 8: return TemplateType.TEMPLATE_4
		5, 7: return TemplateType.TEMPLATE_4L
		6: return TemplateType.TEMPLATE_5
		_: return TemplateType.TEMPLATE_4

func _is_door_tile(pos: Vector2i) -> bool:
	for v in _vestibules:
		if pos == v["door_from"] or pos == v["door_to"]:
			return true
	return false

func _place_rewards(floor_num: int, hub_room: Room, br_room: Room) -> void:
	match floor_num:
		2, 4, 8:
			if br_room != null:
				_place_reward_in_room(br_room, TileType.ALTAR, floor_num)
		3:
			if br_room != null:
				_place_reward_in_room(br_room, TileType.CHEST, floor_num)
		6:
			if br_room != null:
				_place_reward_in_room(br_room, TileType.ALTAR, floor_num)
			if hub_room != null:
				_place_reward_in_room(hub_room, TileType.CHEST, floor_num)

func _place_reward_in_room(target_room: Room, reward_type: TileType, floor_num: int) -> Vector2i:
	var candidates: Array[Vector2i] = []
	var c: Vector2i = Vector2i(target_room.rect.position.x + 2, target_room.rect.position.y + 2)
	candidates.append(c)
	candidates.append(c + Vector2i(1, 0))
	candidates.append(c + Vector2i(-1, 0))
	candidates.append(c + Vector2i(0, 1))
	candidates.append(c + Vector2i(0, -1))

	for ix in range(target_room.rect.position.x + 1, target_room.rect.position.x + 4):
		for iy in range(target_room.rect.position.y + 1, target_room.rect.position.y + 4):
			var p: Vector2i = Vector2i(ix, iy)
			if not candidates.has(p):
				candidates.append(p)

	for p in candidates:
		if p != entrance_pos and p != exit_pos and grid[p.x][p.y] == TileType.FLOOR and not _is_door_tile(p):
			grid[p.x][p.y] = reward_type
			if reward_type == TileType.ALTAR:
				altars.append(p)
			elif reward_type == TileType.CHEST:
				chests.append(p)
			return p

	push_error("CRITICAL ERROR: Failed to place reward in room %s on floor %d!" % [target_room.role, floor_num])
	print("CRITICAL ERROR: Failed to place reward in room %s on floor %d!" % [target_room.role, floor_num])
	return Vector2i(-1, -1)

func _place_enemies(floor_num: int) -> void:
	var floor_idx: int = clampi(floor_num - 1, 0, GameState.ENEMIES_PER_FLOOR.size() - 1)
	var enemy_count: int = GameState.ENEMIES_PER_FLOOR[floor_idx]

	var available_types: Array[Enemy.EnemyType] = []
	available_types.append(Enemy.EnemyType.SKELETON_GRUNT)
	if floor_num >= 1:
		available_types.append(Enemy.EnemyType.GOBLIN_ARCHER)
	if floor_num >= 2:
		available_types.append(Enemy.EnemyType.SHIELD_GUARD)
	if floor_num >= 3:
		available_types.append(Enemy.EnemyType.OGRE_BERSERKER)
	if floor_num >= 4:
		available_types.append(Enemy.EnemyType.SHADOW_STALKER)
	if floor_num >= 5:
		available_types.append(Enemy.EnemyType.CULTIST_MAGE)

	# Build combat rooms list (all non-IN rooms)
	var combat_rooms: Array[Room] = []
	for r in rooms:
		if not r.is_entrance:
			combat_rooms.append(r)

	# Allocation counts per room
	var room_enemies_target: Dictionary = {}
	for r in combat_rooms:
		room_enemies_target[r.id] = 0

	# Pass 1: One enemy per combat room
	var enemies_to_distribute: int = enemy_count
	for r in combat_rooms:
		if enemies_to_distribute > 0:
			room_enemies_target[r.id] += 1
			enemies_to_distribute -= 1

	# Pass 2: Remainder in priority order BR, A, B, MID, HUB, OUT until room has 2
	var remainder_priority_roles: Array[String] = ["BR", "A", "B", "MID", "HUB", "OUT"]
	for role_name in remainder_priority_roles:
		for r in combat_rooms:
			if r.role == role_name and enemies_to_distribute > 0 and room_enemies_target[r.id] < 2:
				room_enemies_target[r.id] += 1
				enemies_to_distribute -= 1

	if enemies_to_distribute > 0:
		push_error("CRITICAL ERROR: Failed to distribute all %d enemies on floor %d!" % [enemy_count, floor_num])
		print("CRITICAL ERROR: Failed to distribute all %d enemies on floor %d!" % [enemy_count, floor_num])

	# Spawn enemies into each room
	for r in combat_rooms:
		var count: int = room_enemies_target[r.id]
		for e_idx in range(count):
			var spawn_pos: Vector2i = _find_enemy_spawn_pos(r, floor_num)
			if spawn_pos == Vector2i(-1, -1):
				push_error("CRITICAL ERROR: Failed to place enemy in room %s on floor %d!" % [r.role, floor_num])
				print("CRITICAL ERROR: Failed to place enemy in room %s on floor %d!" % [r.role, floor_num])
				continue

			var type_idx: int = game_state.randi_range(0, available_types.size() - 1)
			var etype: Enemy.EnemyType = available_types[type_idx]
			var enemy_obj: Enemy = Enemy.new(etype, spawn_pos)
			enemies.append(enemy_obj)

func _has_enemy_at(pos: Vector2i) -> bool:
	for e in enemies:
		if e.pos == pos:
			return true
	return false

func _find_enemy_spawn_pos(target_room: Room, floor_num: int) -> Vector2i:
	var candidates: Array[Vector2i] = []

	if target_room.is_branch:
		# In BR: northern half first, closer to HUB door
		var y1: int = target_room.rect.position.y + 1
		var y2: int = target_room.rect.position.y + 2
		var y3: int = target_room.rect.position.y + 3

		candidates.append(Vector2i(target_room.rect.position.x + 2, y1))
		candidates.append(Vector2i(target_room.rect.position.x + 1, y1))
		candidates.append(Vector2i(target_room.rect.position.x + 3, y1))
		candidates.append(Vector2i(target_room.rect.position.x + 1, y2))
		candidates.append(Vector2i(target_room.rect.position.x + 3, y2))
		candidates.append(Vector2i(target_room.rect.position.x + 2, y2))
		candidates.append(Vector2i(target_room.rect.position.x + 1, y3))
		candidates.append(Vector2i(target_room.rect.position.x + 2, y3))
		candidates.append(Vector2i(target_room.rect.position.x + 3, y3))
	else:
		var c: Vector2i = Vector2i(target_room.rect.position.x + 2, target_room.rect.position.y + 2)
		candidates.append(c)
		candidates.append(c + Vector2i(0, -1))
		candidates.append(c + Vector2i(0, 1))
		candidates.append(c + Vector2i(1, -1))
		candidates.append(c + Vector2i(1, 1))
		candidates.append(c + Vector2i(-1, -1))
		candidates.append(c + Vector2i(-1, 1))
		candidates.append(c + Vector2i(1, 0))
		candidates.append(c + Vector2i(-1, 0))

	for p in candidates:
		if p != entrance_pos and p != exit_pos and grid[p.x][p.y] == TileType.FLOOR and not _is_door_tile(p) and not _has_enemy_at(p):
			return p

	return Vector2i(-1, -1)

func is_walkable(pos: Vector2i) -> bool:
	if pos.x < 0 or pos.x >= width or pos.y < 0 or pos.y >= height:
		return false
	return grid[pos.x][pos.y] != TileType.WALL

# ==============================================================================
# SECTION 7: VALIDATE OR DIE (12 INVARIANTS LD SPECIFICATION)
# ==============================================================================
func validate_or_die(floor_num: int) -> void:
	var template: TemplateType = _get_template_for_floor(floor_num)

	# 1. Room Count = Template
	var expected_rooms: int = 3
	match template:
		TemplateType.TEMPLATE_3: expected_rooms = 3
		TemplateType.TEMPLATE_4: expected_rooms = 4
		TemplateType.TEMPLATE_4L: expected_rooms = 4
		TemplateType.TEMPLATE_5: expected_rooms = 5

	if rooms.size() != expected_rooms:
		push_error("CRITICAL ERROR: validate 1 floor=%d (expected %d rooms, got %d)" % [floor_num, expected_rooms, rooms.size()])
		print("CRITICAL ERROR: validate 1 floor=%d (expected %d rooms, got %d)" % [floor_num, expected_rooms, rooms.size()])

	# 2. Branch rooms count: <= 1 total; 0 on 3 and 4L, 1 on 4 and 5
	var branch_count: int = 0
	for r in rooms:
		if r.is_branch:
			branch_count += 1
	var expected_branches: int = 1 if (template == TemplateType.TEMPLATE_4 or template == TemplateType.TEMPLATE_5) else 0
	if branch_count != expected_branches:
		push_error("CRITICAL ERROR: validate 2 floor=%d (expected %d branches, got %d)" % [floor_num, expected_branches, branch_count])
		print("CRITICAL ERROR: validate 2 floor=%d (expected %d branches, got %d)" % [floor_num, expected_branches, branch_count])

	# 3. Each template edge exists. No extra edges.
	var expected_edges: int = 2
	match template:
		TemplateType.TEMPLATE_3: expected_edges = 2
		TemplateType.TEMPLATE_4: expected_edges = 3
		TemplateType.TEMPLATE_4L: expected_edges = 3
		TemplateType.TEMPLATE_5: expected_edges = 4

	if _vestibules.size() != expected_edges:
		push_error("CRITICAL ERROR: validate 3 floor=%d (expected %d edges, got %d)" % [floor_num, expected_edges, _vestibules.size()])
		print("CRITICAL ERROR: validate 3 floor=%d (expected %d edges, got %d)" % [floor_num, expected_edges, _vestibules.size()])

	# 4. Each vestibule is straight (same x or same y)
	for v in _vestibules:
		var cells: Array = v["cells"]
		if cells.size() > 1:
			var same_x: bool = true
			var same_y: bool = true
			var first: Vector2i = cells[0]
			for c in cells:
				if c.x != first.x: same_x = false
				if c.y != first.y: same_y = false
			if not same_x and not same_y:
				push_error("CRITICAL ERROR: validate 4 floor=%d (vestibule is not straight)" % floor_num)
				print("CRITICAL ERROR: validate 4 floor=%d (vestibule is not straight)" % floor_num)

	# 5. Vestibule length in corridor limits
	for v in _vestibules:
		var length: int = v["length"]
		var is_br: bool = v["is_branch"]
		var min_l: int = 2
		var max_l: int = 3
		if not is_br and (template == TemplateType.TEMPLATE_3 or template == TemplateType.TEMPLATE_4):
			max_l = 4

		if length < min_l or length > max_l:
			push_error("CRITICAL ERROR: validate 5 floor=%d (vestibule length %d outside [%d, %d])" % [floor_num, length, min_l, max_l])
			print("CRITICAL ERROR: validate 5 floor=%d (vestibule length %d outside [%d, %d])" % [floor_num, length, min_l, max_l])

	# 6. Every non-IN room has at least one of: enemy, reward, exit
	for r in rooms:
		if r.is_entrance:
			continue
		var has_enemy: bool = false
		for e in enemies:
			if r.rect.has_point(e.pos):
				has_enemy = true
				break
		var has_altar: bool = false
		for a in altars:
			if r.rect.has_point(a):
				has_altar = true
				break
		var has_chest: bool = false
		for c in chests:
			if r.rect.has_point(c):
				has_chest = true
				break
		var has_exit: bool = r.is_exit

		if not (has_enemy or has_altar or has_chest or has_exit):
			push_error("CRITICAL ERROR: validate 6 floor=%d (empty non-IN room %s)" % [floor_num, r.role])
			print("CRITICAL ERROR: validate 6 floor=%d (empty non-IN room %s)" % [floor_num, r.role])

	# 7. In every room <= 2 enemies
	for r in rooms:
		var e_count: int = 0
		for e in enemies:
			if r.rect.has_point(e.pos):
				e_count += 1
		if e_count > 2:
			push_error("CRITICAL ERROR: validate 7 floor=%d (room %s has %d enemies > 2)" % [floor_num, r.role, e_count])
			print("CRITICAL ERROR: validate 7 floor=%d (room %s has %d enemies > 2)" % [floor_num, r.role, e_count])

	# 8. entrance_pos.x < exit_pos.x
	if entrance_pos.x >= exit_pos.x:
		push_error("CRITICAL ERROR: validate 8 floor=%d (entrance_pos.x %d >= exit_pos.x %d)" % [floor_num, entrance_pos.x, exit_pos.x])
		print("CRITICAL ERROR: validate 8 floor=%d (entrance_pos.x %d >= exit_pos.x %d)" % [floor_num, entrance_pos.x, exit_pos.x])

	# 9. Floors 2/4/6/8: Altar exists, in BR, not on BFS path IN -> OUT
	var br_room: Room = null
	for r in rooms:
		if r.is_branch:
			br_room = r
			break

	if GameState.ALTAR_FLOORS.has(floor_num):
		if altars.size() != 1:
			push_error("CRITICAL ERROR: validate 9 floor=%d (expected 1 altar, got %d)" % [floor_num, altars.size()])
			print("CRITICAL ERROR: validate 9 floor=%d (expected 1 altar, got %d)" % [floor_num, altars.size()])
		else:
			var a_pos: Vector2i = altars[0]
			if br_room == null or not br_room.rect.has_point(a_pos):
				push_error("CRITICAL ERROR: validate 9 floor=%d (altar is not in BR)" % floor_num)
				print("CRITICAL ERROR: validate 9 floor=%d (altar is not in BR)" % floor_num)

			var on_shortest_path: bool = _is_tile_on_shortest_bfs(entrance_pos, exit_pos, a_pos)
			if on_shortest_path:
				push_error("CRITICAL ERROR: validate 9 floor=%d (altar is on BFS shortest path IN->OUT)" % floor_num)
				print("CRITICAL ERROR: validate 9 floor=%d (altar is on BFS shortest path IN->OUT)" % floor_num)
	else:
		if not altars.is_empty():
			push_error("CRITICAL ERROR: validate 9 floor=%d (unexpected altar present)" % floor_num)
			print("CRITICAL ERROR: validate 9 floor=%d (unexpected altar present)" % floor_num)

	# 10. Floors 3/6: Chest exists. On 3 in BR. On 6 in HUB (not in BR).
	var hub_room: Room = null
	for r in rooms:
		if r.is_hub:
			hub_room = r
			break

	if GameState.CHEST_FLOORS.has(floor_num):
		if chests.size() != 1:
			push_error("CRITICAL ERROR: validate 10 floor=%d (expected 1 chest, got %d)" % [floor_num, chests.size()])
			print("CRITICAL ERROR: validate 10 floor=%d (expected 1 chest, got %d)" % [floor_num, chests.size()])
		else:
			var c_pos: Vector2i = chests[0]
			if floor_num == 3:
				if br_room == null or not br_room.rect.has_point(c_pos):
					push_error("CRITICAL ERROR: validate 10 floor=3 (chest is not in BR)" % floor_num)
					print("CRITICAL ERROR: validate 10 floor=3 (chest is not in BR)" % floor_num)
			elif floor_num == 6:
				if hub_room == null or not hub_room.rect.has_point(c_pos) or (br_room != null and br_room.rect.has_point(c_pos)):
					push_error("CRITICAL ERROR: validate 10 floor=6 (chest is not in HUB or in BR)" % floor_num)
					print("CRITICAL ERROR: validate 10 floor=6 (chest is not in HUB or in BR)" % floor_num)
	else:
		if not chests.is_empty():
			push_error("CRITICAL ERROR: validate 10 floor=%d (unexpected chest present)" % floor_num)
			print("CRITICAL ERROR: validate 10 floor=%d (unexpected chest present)" % floor_num)

	# 11. Manhattan from BR door to BR reward <= 3
	if br_room != null:
		var br_door: Vector2i = Vector2i(br_room.rect.position.x + 2, br_room.rect.position.y)
		var br_reward: Vector2i = Vector2i(-1, -1)
		if not altars.is_empty() and br_room.rect.has_point(altars[0]):
			br_reward = altars[0]
		elif not chests.is_empty() and br_room.rect.has_point(chests[0]):
			br_reward = chests[0]

		if br_reward != Vector2i(-1, -1):
			var dist: int = absi(br_door.x - br_reward.x) + absi(br_door.y - br_reward.y)
			if dist > 3:
				push_error("CRITICAL ERROR: validate 11 floor=%d (BR door to reward dist %d > 3)" % [floor_num, dist])
				print("CRITICAL ERROR: validate 11 floor=%d (BR door to reward dist %d > 3)" % [floor_num, dist])

	# 12. Grid 32x16, each room margin >= 1 to edge
	if width != 32 or height != 16:
		push_error("CRITICAL ERROR: validate 12 floor=%d (grid size %dx%d != 32x16)" % [floor_num, width, height])
		print("CRITICAL ERROR: validate 12 floor=%d (grid size %dx%d != 32x16)" % [floor_num, width, height])

	for r in rooms:
		if r.rect.position.x < 1 or r.rect.position.y < 1 or (r.rect.position.x + r.rect.size.x > 31) or (r.rect.position.y + r.rect.size.y > 15):
			push_error("CRITICAL ERROR: validate 12 floor=%d (room %s out of bounds: %s)" % [floor_num, r.role, str(r.rect)])
			print("CRITICAL ERROR: validate 12 floor=%d (room %s out of bounds: %s)" % [floor_num, r.role, str(r.rect)])

func _is_tile_on_shortest_bfs(from: Vector2i, to: Vector2i, tile: Vector2i) -> bool:
	if tile == from or tile == to:
		return true

	var queue: Array[Vector2i] = [from]
	var came_from: Dictionary = {}
	came_from[from] = from
	var dirs: Array[Vector2i] = [Vector2i(0, -1), Vector2i(0, 1), Vector2i(-1, 0), Vector2i(1, 0)]
	var found: bool = false

	while not queue.is_empty():
		var current: Vector2i = queue.pop_front()
		if current == to:
			found = true
			break

		for d in dirs:
			var next: Vector2i = current + d
			if is_walkable(next) and not came_from.has(next):
				came_from[next] = current
				queue.append(next)

	if not found:
		return false

	var curr: Vector2i = to
	while came_from.has(curr) and came_from[curr] != from:
		if curr == tile:
			return true
		curr = came_from[curr]

	return false

# КОНЕЦ ФАЙЛА scripts/dungeon_generator.gd

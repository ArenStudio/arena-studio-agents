extends RefCounted

const GameState = preload("res://scripts/game_state.gd")
const Player = preload("res://scripts/player.gd")
const DungeonGenerator = preload("res://scripts/dungeon_generator.gd")
const CombatSystem = preload("res://scripts/combat_system.gd")
const Enemy = preload("res://scripts/enemy.gd")

var game_state: GameState
var player: Player
var dungeon: DungeonGenerator
var combat: CombatSystem

# Audit hooks for --altar-audit (GP-012)
var audit_active: bool = false
var audit_p5_hp_fired_this_turn: bool = false
var audit_pickup_targeted_this_turn: bool = false

func _init(p_game_state: GameState, p_player: Player, p_dungeon: DungeonGenerator, p_combat: CombatSystem) -> void:
	game_state = p_game_state
	player = p_player
	dungeon = p_dungeon
	combat = p_combat

func decide_and_act() -> void:
	# 1. Take Stairs if standing on Exit (when exit is intentional or no reachable pickup in range)
	if player.pos == dungeon.exit_pos:
		var should_descend: bool = true
		if game_state.current_floor < GameState.MAX_FLOORS and player.hp > 8:
			var target_pickup: Vector2i = Vector2i(-1, -1)
			var min_pickup_dist: int = 27
			for a_pos in dungeon.altars:
				if dungeon.grid[a_pos.x][a_pos.y] == DungeonGenerator.TileType.ALTAR:
					var d: int = absi(player.pos.x - a_pos.x) + absi(player.pos.y - a_pos.y)
					if d <= min_pickup_dist:
						min_pickup_dist = d
						target_pickup = a_pos
			for c_pos in dungeon.chests:
				if dungeon.grid[c_pos.x][c_pos.y] == DungeonGenerator.TileType.CHEST:
					var d: int = absi(player.pos.x - c_pos.x) + absi(player.pos.y - c_pos.y)
					if d <= min_pickup_dist:
						min_pickup_dist = d
						target_pickup = c_pos
			if target_pickup != Vector2i(-1, -1) and get_best_nav_step(player.pos, target_pickup) != player.pos:
				should_descend = false

		if should_descend:
			combat.execute_player_use_stairs()
			return

	var dirs: Array[Vector2i] = [Vector2i(0, -1), Vector2i(0, 1), Vector2i(-1, 0), Vector2i(1, 0)]
	var adjacent_enemies: Array[Enemy] = []
	for d in dirs:
		var e: Enemy = combat.get_enemy_at(player.pos + d)
		if e != null and e.is_alive():
			adjacent_enemies.append(e)

	# 2. Evade Telegraphed Danger (Exact Shape: 3x3 for AoE, single tile for Slam)
	for e in dungeon.enemies:
		if e.is_alive():
			var in_danger: bool = false
			if e.intent_type == Enemy.IntentType.SLAM and player.pos == e.intent_target:
				in_danger = true
			elif e.intent_type in [Enemy.IntentType.AOE_DETONATE, Enemy.IntentType.CAST_AOE]:
				if absi(player.pos.x - e.intent_target.x) <= 1 and absi(player.pos.y - e.intent_target.y) <= 1:
					in_danger = true

			if in_danger:
				for d in dirs:
					var safe_cand: Vector2i = player.pos + d
					if dungeon.is_walkable(safe_cand) and combat.get_enemy_at(safe_cand) == null:
						var cand_in_aoe: bool = (e.intent_type in [Enemy.IntentType.AOE_DETONATE, Enemy.IntentType.CAST_AOE]) and (absi(safe_cand.x - e.intent_target.x) <= 1 and absi(safe_cand.y - e.intent_target.y) <= 1)
						var cand_in_slam: bool = (e.intent_type == Enemy.IntentType.SLAM) and (safe_cand == e.intent_target)
						if not cand_in_aoe and not cand_in_slam:
							game_state.counters["telegraphs_evaded"] += 1
							combat.execute_player_move(d)
							return

	# 3. DASH USAGE (Gap-close on Archer/Mage at distance 2 or 3, or escape surround)
	if player.can_afford(GameState.COST_DASH):
		# A. Escape surround
		if adjacent_enemies.size() >= 2:
			for d in dirs:
				var step2: Vector2i = player.pos + d * 2
				if dungeon.is_walkable(step2) and combat.get_enemy_at(step2) == null:
					combat.execute_player_dash(d)
					return

		# B. Gap-close on Ranged Archer / Cultist Mage at distance 2
		for d in dirs:
			var target2: Vector2i = player.pos + d * 2
			var e2: Enemy = combat.get_enemy_at(target2)
			if e2 != null and e2.is_alive() and (e2.type == Enemy.EnemyType.GOBLIN_ARCHER or e2.type == Enemy.EnemyType.CULTIST_MAGE) and dungeon.is_walkable(player.pos + d):
				combat.execute_player_dash(d)
				return

		# C. Gap-close on Ranged Archer at distance 3 along corridor
		for d in dirs:
			var target3: Vector2i = player.pos + d * 3
			var e3: Enemy = combat.get_enemy_at(target3)
			if e3 != null and e3.is_alive() and e3.type == Enemy.EnemyType.GOBLIN_ARCHER and dungeon.is_walkable(player.pos + d * 2) and combat.get_enemy_at(player.pos + d * 2) == null:
				combat.execute_player_dash(d)
				return

	# 4. ADJACENT COMBAT RESOLUTION (BAL-001 Balanced Tactical Matrix)
	if not adjacent_enemies.is_empty():
		# A. Kill 1-hit killable enemy immediately (Basic Attack)
		for e in adjacent_enemies:
			if not e.is_shielded and e.hp <= player.base_damage:
				combat.execute_player_basic_attack(e)
				return

		# B. Crush high-HP dangerous enemy (8 dmg + Stun prevents enemy retaliation)
		if player.can_afford(GameState.COST_CRUSH):
			for e in adjacent_enemies:
				if e.hp >= 10 and not e.is_shielded:
					combat.execute_player_crush(e.pos - player.pos)
					return

		# C. Block incoming attack to preserve HP (hp <= 20)
		var incoming_attack: bool = false
		for e in adjacent_enemies:
			if e.intent_type == Enemy.IntentType.ATTACK and not e.is_stunned:
				incoming_attack = true
				break
		if incoming_attack and player.can_afford(GameState.COST_BLOCK) and player.hp <= 20:
			combat.execute_player_block()
			return

		# D. Attack unshielded enemy
		var unshielded: Array[Enemy] = []
		for e in adjacent_enemies:
			if not e.is_shielded:
				unshielded.append(e)
		if not unshielded.is_empty():
			unshielded.sort_custom(func(a, b): return a.hp < b.hp)
			combat.execute_player_basic_attack(unshielded[0])
			return

		# E. Block if enemy is shielded
		if player.can_afford(GameState.COST_BLOCK):
			combat.execute_player_block()
			return
		combat.execute_player_basic_attack(adjacent_enemies[0])
		return

	# 5. On Floor 8 or when low on HP (<= 8), rush directly to Exit
	if game_state.current_floor == GameState.MAX_FLOORS or player.hp <= 8:
		var exit_step: Vector2i = get_best_nav_step(player.pos, dungeon.exit_pos)
		if exit_step != player.pos:
			if audit_active and player.hp <= 8:
				audit_p5_hp_fired_this_turn = true
			combat.execute_player_move(exit_step - player.pos)
			return

	# 6. Collect Altars of Focus and Chests on floor (LD threshold: radius up to 27)
	var target_pickup: Vector2i = Vector2i(-1, -1)
	var min_pickup_dist: int = 27

	for a_pos in dungeon.altars:
		if dungeon.grid[a_pos.x][a_pos.y] == DungeonGenerator.TileType.ALTAR:
			var d: int = absi(player.pos.x - a_pos.x) + absi(player.pos.y - a_pos.y)
			if d <= min_pickup_dist:
				min_pickup_dist = d
				target_pickup = a_pos

	for c_pos in dungeon.chests:
		if dungeon.grid[c_pos.x][c_pos.y] == DungeonGenerator.TileType.CHEST:
			var d: int = absi(player.pos.x - c_pos.x) + absi(player.pos.y - c_pos.y)
			if d <= min_pickup_dist:
				min_pickup_dist = d
				target_pickup = c_pos

	if target_pickup != Vector2i(-1, -1):
		var step_item: Vector2i = get_best_nav_step(player.pos, target_pickup)
		if step_item != player.pos:
			if audit_active:
				audit_pickup_targeted_this_turn = true
			combat.execute_player_move(step_item - player.pos)
			return

	# 7. Navigate directly to Exit stairs
	var next_step: Vector2i = get_best_nav_step(player.pos, dungeon.exit_pos)
	if next_step != player.pos:
		var move_dir: Vector2i = next_step - player.pos
		combat.execute_player_move(move_dir)
	else:
		combat.execute_player_wait()

func get_best_nav_step(from: Vector2i, to: Vector2i) -> Vector2i:
	if from == to:
		return from

	var queue: Array[Vector2i] = [from]
	var came_from: Dictionary = {}
	came_from[from] = from
	var dirs: Array[Vector2i] = [Vector2i(0, -1), Vector2i(0, 1), Vector2i(-1, 0), Vector2i(1, 0)]
	var found: bool = false

	while not queue.is_empty():
		var current: Vector2i = queue.pop_front()
		if current == to:
			found = true
			break

		for d in dirs:
			var next: Vector2i = current + d
			if dungeon.is_walkable(next) and not came_from.has(next):
				came_from[next] = current
				queue.append(next)

	if not found:
		return from

	var curr: Vector2i = to
	while came_from.has(curr) and came_from[curr] != from:
		curr = came_from[curr]

	return curr

# КОНЕЦ ФАЙЛА scripts/autoplayer.gd

class_name EnemyDamageSlot
extends RefCounted

# ==============================================================================
# ROGUE-02 / GP-023 (v23, diagnostic spike)
#
# АРБИТР ПРАВА НАНЕСЕНИЯ УРОНА ("слот урона").
#
# Ровно ОДИН враг за ход получает право нанести непосредственный урон в
# обычной фазе врагов. Остальные враги ходят как обычно: перемещаются,
# занимают позицию, готовят отложенную атаку, перекрывают клетки.
#
# Модуль НЕ наносит урон и НЕ двигает врагов. Он только отвечает на вопрос
# "кто из кандидатов имеет право ударить в этом ходу" и удерживает инвариант
# "не более одного пакета непосредственного урона за ход".
#
# ДЕТЕРМИНИЗМ: выбор не зависит от порядка обхода коллекции, от адресов
# объектов, от кадров и от времени. Кандидаты сравниваются по СТРОГОМУ
# ПОЛНОМУ порядку (последний ключ — уникальный enemy_id), поэтому равных
# элементов не существует и результат не зависит от алгоритма сортировки.
# Выбор реализован линейным поиском минимума, а не Array.sort_custom,
# именно чтобы исключить зависимость от стабильности сортировки.
#
# НЕ ПОДЧИНЯЮТСЯ ЭТОМУ ОГРАНИЧЕНИЮ (проходят мимо модуля, как и раньше):
#   - урон Преследования / Стагнации;
#   - ответный урон;
#   - урон от столкновения врагов при Сокрушении;
#   - явно обозначенные фазы боссов.
# ==============================================================================

# На сколько ходов вперёд телеграф может забронировать слот.
const RESERVE_HORIZON: int = 2

# Значение "нет держателя".
const NO_HOLDER: int = -1

# turn -> enemy_id. Бронь слота отложенной атакой (телеграфом).
var _reservations: Dictionary = {}

# enemy_id -> номер хода, когда враг ПОСЛЕДНИЙ РАЗ реально нанёс урон.
var _last_attack_turn: Dictionary = {}

# enemy_id -> номер хода, когда враг впервые стал кандидатом.
# Нужен, чтобы новичок не получал фиктивно огромный "голод".
var _first_seen_turn: Dictionary = {}

# Состояние текущего хода.
var _turn: int = -1
var _holder: int = NO_HOLDER
var _spent: bool = false

# Враги, уже пытавшиеся получить слот в этом ходу и выбывшие.
# Защита от бесконечного переизбрания.
var _tried: Dictionary = {}


func reset_floor() -> void:
	_reservations.clear()
	_last_attack_turn.clear()
	_first_seen_turn.clear()
	_turn = -1
	_holder = NO_HOLDER
	_spent = false
	_tried.clear()


func begin_turn(turn_index: int) -> void:
	# Внутри одного забега номер хода строго возрастает: _resolve_enemy_actions
	# вызывается ровно один раз за ход, уже после total_turns += 1.
	# Значит turn_index <= _turn означает начало НОВОГО забега на том же
	# экземпляре CombatSystem (--eval-batch прогоняет сотни сидов подряд).
	# Без этого сброса состояние предыдущего сида протекло бы в следующий
	# и сломало бы детерминизм и воспроизводимость хешей.
	if turn_index <= _turn:
		reset_floor()
	_turn = turn_index
	_holder = NO_HOLDER
	_spent = false
	_tried.clear()


func get_holder() -> int:
	return _holder


func is_spent() -> bool:
	return _spent


# Сколько ходов враг не наносил урона. Новичок получает ровно 1, а не
# бесконечность: иначе каждый заспавненный враг перебивал бы всех остальных.
func _starvation(enemy_id: int) -> int:
	if _last_attack_turn.has(enemy_id):
		return _turn - int(_last_attack_turn[enemy_id])
	var seen: int = _turn
	if _first_seen_turn.has(enemy_id):
		seen = int(_first_seen_turn[enemy_id])
	return _turn - (seen - 1)


# Строгий полный порядок. Возвращает true, если A имеет приоритет над B.
# Порядок ключей: голод (убыв.) -> дистанция (возр.) -> y -> x -> id.
# Совпадение всех пяти ключей невозможно, id уникален.
func _has_priority(a: Dictionary, b: Dictionary) -> bool:
	var sa: int = _starvation(int(a["id"]))
	var sb: int = _starvation(int(b["id"]))
	if sa != sb:
		return sa > sb
	var da: int = int(a["dist"])
	var db: int = int(b["dist"])
	if da != db:
		return da < db
	var ya: int = int(a["y"])
	var yb: int = int(b["y"])
	if ya != yb:
		return ya < yb
	var xa: int = int(a["x"])
	var xb: int = int(b["x"])
	if xa != xb:
		return xa < xb
	return int(a["id"]) < int(b["id"])


# Главная точка входа.
# candidates: Array[Dictionary] с ключами id:int, x:int, y:int, dist:int.
# dist — чебышёвское расстояние до игрока, считает вызывающая сторона.
# Возвращает enemy_id держателя слота либо NO_HOLDER.
func select_attacker(candidates: Array) -> int:
	for c in candidates:
		var cid: int = int(c["id"])
		if not _first_seen_turn.has(cid):
			_first_seen_turn[cid] = _turn

	if _spent:
		return NO_HOLDER

	# 1. Бронь телеграфом связывает безусловно: враг, объявивший удар,
	#    обязан его получить, иначе телеграф — ложь для игрока.
	if _reservations.has(_turn):
		var reserved: int = int(_reservations[_turn])
		for c in candidates:
			if int(c["id"]) == reserved and not _tried.has(reserved):
				_holder = reserved
				return _holder
		# Бронировавший выбыл или не в списке кандидатов — бронь сгорает,
		# слот не должен пропадать вместе с ним.
		_reservations.erase(_turn)

	# 2. Обычный выбор: линейный поиск минимума по строгому полному порядку.
	var best: Dictionary = {}
	var found: bool = false
	for c in candidates:
		if _tried.has(int(c["id"])):
			continue
		if not found:
			best = c
			found = true
		elif _has_priority(c, best):
			best = c

	if not found:
		_holder = NO_HOLDER
		return NO_HOLDER

	_holder = int(best["id"])
	return _holder


# Урон реально нанесён. Закрывает слот до конца хода.
func consume(enemy_id: int) -> void:
	if _spent:
		push_error("EnemyDamageSlot: попытка нанести второй пакет урона за ход %d" % _turn)
		return
	if enemy_id != _holder:
		push_error("EnemyDamageSlot: урон наносит не держатель слота (%d != %d)" % [enemy_id, _holder])
		return
	_spent = true
	_last_attack_turn[enemy_id] = _turn
	_reservations.erase(_turn)


# Держатель не смог ударить (погиб, отброшен, потерял линию).
# Слот переходит следующему по приоритету, но не по кругу.
func drop_holder() -> void:
	if _holder != NO_HOLDER:
		_tried[_holder] = true
		_holder = NO_HOLDER


# Телеграф: занять ближайший свободный будущий ход.
# Возвращает номер хода или NO_HOLDER, если горизонт занят.
func try_reserve(enemy_id: int) -> int:
	for t in range(_turn + 1, _turn + 1 + RESERVE_HORIZON):
		if not _reservations.has(t):
			_reservations[t] = enemy_id
			return t
	return NO_HOLDER


func has_reservation(enemy_id: int) -> bool:
	for t in _reservations.keys():
		if int(_reservations[t]) == enemy_id:
			return true
	return false


# Снять бронь врага (погиб, потерял цель, прервал замах).
func release(enemy_id: int) -> void:
	var doomed: Array = []
	for t in _reservations.keys():
		if int(_reservations[t]) == enemy_id:
			doomed.append(t)
	for t in doomed:
		_reservations.erase(t)


# Диагностика для QA и --manual. Не влияет на симуляцию.
func debug_line() -> String:
	return "slot[turn=%d holder=%d spent=%s reserved=%s]" % [
		_turn, _holder, str(_spent), str(_reservations)
	]

# КОНЕЦ ФАЙЛА scripts/enemy_damage_slot.gd

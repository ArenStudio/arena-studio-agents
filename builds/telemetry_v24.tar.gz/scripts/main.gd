class_name Main
extends Node2D

const GameState = preload("res://scripts/game_state.gd")
const Player = preload("res://scripts/player.gd")
const DungeonGenerator = preload("res://scripts/dungeon_generator.gd")
const CombatSystem = preload("res://scripts/combat_system.gd")
const Enemy = preload("res://scripts/enemy.gd")
const Autoplayer = preload("res://scripts/autoplayer.gd")

var game_state: GameState
var player: Player
var dungeon: DungeonGenerator
var combat: CombatSystem
var autoplayer: Autoplayer

var target_mode: String = ""
var cell_size: int = 18
var origin_x: int = 24
var origin_y: int = 90

func _init() -> void:
	game_state = GameState.new()
	player = Player.new(game_state)
	dungeon = DungeonGenerator.new(game_state)
	combat = CombatSystem.new(game_state, player, dungeon)
	autoplayer = Autoplayer.new(game_state, player, dungeon, combat)

func _ready() -> void:
	if game_state == null:
		_init()

	var args: PackedStringArray = OS.get_cmdline_user_args()
	if args.is_empty():
		args = OS.get_cmdline_args()

	var is_headless: bool = DisplayServer.get_name() == "headless" or "--headless" in args

	if is_headless:
		_run_headless_mode(args)
	else:
		_start_new_game(12345)

func _start_new_game(seed_val: int) -> void:
	game_state.reset(seed_val)
	player.reset()
	dungeon.generate_floor(1)
	player.pos = dungeon.entrance_pos
	combat.calculate_all_enemy_intents()
	combat.log_message("=== ROGUE-02: ТОЧКА НЕВОЗВРАТА ===")
	combat.log_message("Спуск начат. Запас преследования: 120 единиц на этаж.")
	queue_redraw()

# ==============================================================================
# HEADLESS RUNNER & AUTOMATED AUDIT (AC1 - AC5 / R-008, D-002, D-003)
# ==============================================================================
func _run_headless_mode(args: PackedStringArray) -> void:
	var seed_val: int = 12345
	var mode: String = "autoplay"
	var custom_moves: String = ""

	var i: int = 0
	while i < args.size():
		var arg: String = args[i]
		if arg.begins_with("--seed="):
			seed_val = arg.substr(7).to_int()
		elif arg == "--seed" and i + 1 < args.size():
			i += 1
			seed_val = args[i].to_int()
		elif arg == "--test-wait":
			mode = "test_wait"
		elif arg == "--test-determ":
			mode = "test_determ"
		elif arg == "--test-victory":
			mode = "test_victory"
		elif arg == "--eval-batch" and i + 2 < args.size():
			i += 1
			var b_start: int = args[i].to_int()
			i += 1
			var b_end: int = args[i].to_int()
			_run_batch_eval(b_start, b_end)
			get_tree().quit()
			return
		elif (arg == "--altar-audit" or arg == "-altar-audit") and i + 2 < args.size():
			i += 1
			var a_start: int = args[i].to_int()
			i += 1
			var a_end: int = args[i].to_int()
			_run_altar_audit(a_start, a_end)
			get_tree().quit()
			return
		elif arg == "--manual" or arg == "-manual":
			mode = "manual"
		elif arg == "--autoplay":
			mode = "autoplay"
		elif arg.begins_with("--moves="):
			mode = "moves"
			custom_moves = arg.substr(8)
		elif arg == "--moves" and i + 1 < args.size():
			i += 1
			mode = "moves"
			custom_moves = args[i]
		i += 1

	print("\n[ROGUE-02 HEADLESS INITIALIZED: SEED %d, MODE: %s]" % [seed_val, mode])

	if mode == "test_determ":
		_run_determinism_test(seed_val)
	elif mode == "test_wait":
		_run_wait_doom_test(seed_val)
	elif mode == "test_victory":
		_run_victory_test(seed_val)
	elif mode == "moves":
		_run_custom_moves(seed_val, custom_moves)
	elif mode == "manual":
		_run_manual_mode(seed_val)
	else:
		_run_autoplay_simulation(seed_val)

	get_tree().quit()

func _run_batch_eval(start_seed: int, end_seed: int) -> void:
	var N: int = end_seed - start_seed + 1
	var victories: int = 0
	var vic_seeds: Array[int] = []
	var vic_focuses: Array[int] = []
	var dash_runs: int = 0

	var total_dash: int = 0
	var total_block: int = 0
	var total_crush: int = 0
	var total_attacks: int = 0
	var total_moves: int = 0
	var total_waits: int = 0
	var total_altars_presented: int = 0
	var total_altars_legacy: int = 0
	var total_altars_collected: int = 0
	var total_telegraphs_evaded: int = 0
	var runs_with_evasion: int = 0

	var presented_by_floor: Dictionary = {2: 0, 4: 0, 6: 0, 8: 0}
	var collected_by_floor: Dictionary = {2: 0, 4: 0, 6: 0, 8: 0}

	var results: Array[Dictionary] = []

	for s in range(start_seed, end_seed + 1):
		var res: Dictionary = _simulate_autoplay(s)
		results.append(res)

		if res["dash_used"] > 0:
			dash_runs += 1
		if res["telegraphs_evaded"] > 0:
			runs_with_evasion += 1
		if res["outcome"] == "VICTORY":
			victories += 1
			vic_seeds.append(s)
			vic_focuses.append(res["focus_gained"])

		total_dash += res["dash_used"]
		total_block += res["block_used"]
		total_crush += res["crush_used"]
		total_attacks += res["basic_attacks"]
		total_moves += res["moves_made"]
		total_waits += res["waits_made"]
		total_altars_collected += res["altars_visited"]
		total_telegraphs_evaded += res["telegraphs_evaded"]

		# AC1 & AC2: Count altars presented (f >= af) vs legacy completed floors (f > af)
		var f: int = res["floor"]
		for af in GameState.ALTAR_FLOORS:
			if f >= af:
				total_altars_presented += 1
				presented_by_floor[af] += 1
			if f > af:
				total_altars_legacy += 1

		if res.has("altars_by_floor"):
			for af in GameState.ALTAR_FLOORS:
				collected_by_floor[af] += res["altars_by_floor"].get(af, 0)

	var winrate: float = float(victories) / float(N)
	var z: float = 1.96
	var denom: float = 1.0 + (z * z) / float(N)
	var centre: float = (winrate + (z * z) / (2.0 * float(N))) / denom
	var margin: float = (z * sqrt((winrate * (1.0 - winrate) + (z * z) / (4.0 * float(N))) / float(N))) / denom
	var ci_low: float = maxf(0.0, (centre - margin) * 100.0)
	var ci_high: float = minf(100.0, (centre + margin) * 100.0)

	var res_sum: int = total_dash + total_block + total_crush
	var dash_pct: float = float(total_dash) / float(res_sum) * 100.0 if res_sum > 0 else 0.0
	var block_pct: float = float(total_block) / float(res_sum) * 100.0 if res_sum > 0 else 0.0
	var crush_pct: float = float(total_crush) / float(res_sum) * 100.0 if res_sum > 0 else 0.0

	vic_focuses.sort()
	var med_focus: int = vic_focuses[vic_focuses.size() / 2] if not vic_focuses.is_empty() else 0
	var altar_presented_rate: float = float(total_altars_collected) / float(total_altars_presented) * 100.0 if total_altars_presented > 0 else 0.0
	var altar_legacy_rate: float = float(total_altars_collected) / float(total_altars_legacy) * 100.0 if total_altars_legacy > 0 else 0.0

	var death_floors: Array[int] = []
	for r in results:
		if r["outcome"] == "DEFEAT":
			death_floors.append(r["floor"])
	death_floors.sort()
	var med_death_floor: int = death_floors[death_floors.size() / 2] if not death_floors.is_empty() else 0

	var altars_246_presented: int = presented_by_floor[2] + presented_by_floor[4] + presented_by_floor[6]
	var altars_246_collected: int = collected_by_floor[2] + collected_by_floor[4] + collected_by_floor[6]
	var altars_246_rate: float = float(altars_246_collected) / float(altars_246_presented) * 100.0 if altars_246_presented > 0 else 0.0

	var rate_f2: float = float(collected_by_floor[2]) / float(presented_by_floor[2]) * 100.0 if presented_by_floor[2] > 0 else 0.0
	var rate_f4: float = float(collected_by_floor[4]) / float(presented_by_floor[4]) * 100.0 if presented_by_floor[4] > 0 else 0.0
	var rate_f6: float = float(collected_by_floor[6]) / float(presented_by_floor[6]) * 100.0 if presented_by_floor[6] > 0 else 0.0
	var rate_f8: float = float(collected_by_floor[8]) / float(presented_by_floor[8]) * 100.0 if presented_by_floor[8] > 0 else 0.0

	print("=== ПОЛНЫЙ ЗАМЕР ПО ЗАРАНЕЕ ОБЪЯВЛЕННЫМ СИДАМ (%d–%d, N=%d) ===" % [start_seed, end_seed, N])
	print("1. ВИНРЕЙТ (AC1 / AC3):")
	print("   - Размер выборки: N = %d" % N)
	print("   - Побед: %d из %d (%0.1f%%)" % [victories, N, winrate * 100.0])
	print("   - 95%% Доверительный интервал (Wilson score): %0.1f%% – %0.1f%%" % [ci_low, ci_high])
	print("   - Целевой коридор SYS (10–30%%): %s" % ("PASS" if winrate * 100.0 >= 10.0 and winrate * 100.0 <= 30.0 else "FAIL"))
	print("   - Список победных seed (%d): %s" % [vic_seeds.size(), str(vic_seeds)])
	print("   - Медиана этажа гибели: %d этаж" % med_death_floor)

	print("\n2. СОБИРАЕМОСТЬ АЛТАРЕЙ (D-115 / AC1 - AC4):")
	print("   - Итог по этажам 2, 4, 6 (целевой срез): %d предъявлено, %d собрано (%0.1f%%) [Порог >= 75%% -> %s]" % [
		altars_246_presented, altars_246_collected, altars_246_rate, "PASS" if altars_246_rate >= 75.0 else "FAIL"
	])
	print("   - Разрез по этажам (AC1 / AC3):")
	print("     * Этаж 2: %d предъявлено, %d собрано (%0.1f%%)" % [presented_by_floor[2], collected_by_floor[2], rate_f2])
	print("     * Этаж 4: %d предъявлено, %d собрано (%0.1f%%)" % [presented_by_floor[4], collected_by_floor[4], rate_f4])
	print("     * Этаж 6: %d предъявлено, %d собрано (%0.1f%%)" % [presented_by_floor[6], collected_by_floor[6], rate_f6])
	print("     * Этаж 8 (Exit Rush, справочно): %d предъявлено, %d собрано (%0.1f%%)" % [presented_by_floor[8], collected_by_floor[8], rate_f8])
	print("   - Общий итог по всем этажам 1-8 (событийная): %d предъявлено, %d собрано (%0.1f%%) [Порог >= 70%% -> %s]" % [
		total_altars_presented, total_altars_collected, altar_presented_rate, "PASS" if altar_presented_rate >= 70.0 else "FAIL"
	])
	print("   - Legacy метрика (по завершённым этажам f > af): %d учтено, %d собрано (%0.1f%%) [%s]" % [
		total_altars_legacy, total_altars_collected, altar_legacy_rate, "PASS" if altar_legacy_rate >= 70.0 else "FAIL"
	])

	print("\n3. РЫВОК (AC2 / R-002):")
	print("   - Прогонов с применением Рывка: %d из %d (%0.1f%%)" % [dash_runs, N, float(dash_runs) / float(N) * 100.0])
	print("   - Порог (>= 20%%): %s" % ("PASS" if float(dash_runs) / float(N) * 100.0 >= 20.0 else "FAIL"))

	print("\n4. ПРАВИЛО BAL-001 (Доли ресурсных действий внутри класса, 10–60%%):")
	print("   - Рывок (Dash): %d (%0.1f%%) -> %s" % [total_dash, dash_pct, "PASS" if dash_pct >= 10.0 and dash_pct <= 60.0 else "FAIL"])
	print("   - Блок (Block): %d (%0.1f%%) -> %s" % [total_block, block_pct, "PASS" if block_pct >= 10.0 and block_pct <= 60.0 else "FAIL"])
	print("   - Сокрушение (Crush): %d (%0.1f%%) -> %s" % [total_crush, crush_pct, "PASS" if crush_pct >= 10.0 and crush_pct <= 60.0 else "FAIL"])

	print("\n5. ФОКУС ПОБЕДНЫХ ПРОГОНОВ (AC3):")
	print("   - Значения на победах: %s" % str(vic_focuses))
	print("   - Медиана победных: %d (Цель: 25–40) -> %s" % [med_focus, "PASS" if med_focus >= 25 and med_focus <= 40 else "CHECK"])

	print("\n6. ТАКТИЧЕСКИЕ УКЛОНЕНИЯ (AC3):")
	print("   - Прогонов с уклонением от телеграфов: %d из %d (%0.1f%%)" % [
		runs_with_evasion, N, float(runs_with_evasion) / float(N) * 100.0
	])
	print("   - Всего уклонений от телеграфов (AoE/Slam): %d (в среднем %0.2f за прогон)" % [
		total_telegraphs_evaded, float(total_telegraphs_evaded) / float(N)
	])

	print("\nТаблица первых 20 сидов выборки:")
	print("| Seed | Исход | Этаж | Ходы | Фокус | Рывок | Блок | Сокруш | Атака | Перемещ | State Hash |")
	print("| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |")
	for idx in range(mini(20, results.size())):
		var r = results[idx]
		print("| %d | **%s** | %d/8 | %d | %d | %d | %d | %d | %d | %d | %s |" % [
			r["seed"], r["outcome"], r["floor"], r["turns"], r["focus_gained"],
			r["dash_used"], r["block_used"], r["crush_used"], r["basic_attacks"], r["moves_made"], r["state_hash"]
		])
	print("=====================================\n")

func _print_summary(res: Dictionary) -> void:
	print("\n=== ROGUE-02 HEADLESS RUN SUMMARY ===")
	print("SEED: %d" % res["seed"])
	print("STATE HASH: %s" % res["state_hash"])
	print("FLOOR: %d/%d" % [res["floor"], GameState.MAX_FLOORS])
	print("TOTAL TURNS: %d" % res["turns"])
	print("OUTCOME: %s" % res["outcome"])
	print("REASON: %s" % res["reason"])
	print("PLAYER HP: %d/%d" % [res["hp"], GameState.PLAYER_MAX_HP])
	print("PLAYER FOCUS: %d/%d" % [res["focus"], GameState.PLAYER_MAX_FOCUS])
	print("FOCUS TELEMETRY:")
	print("  - FOCUS GAINED: %d (Kills: +%d, Altars: +%d, Chests: +%d)" % [
		res["focus_gained"], res["focus_gained_kills"], res["focus_gained_altars"], res["focus_gained_chests"]
	])
	print("  - FOCUS SPENT: %d (Dash: -%d, Block: -%d, Crush: -%d)" % [
		res["focus_spent_total"], res["focus_spent_dash"], res["focus_spent_block"], res["focus_spent_crush"]
	])
	print("MECHANIC COUNTERS:")
	print("  - Dash Used: %d" % res["dash_used"])
	print("  - Block Used: %d" % res["block_used"])
	print("  - Crush Used: %d" % res["crush_used"])
	print("  - Basic Attacks: %d" % res["basic_attacks"])
	print("  - Moves Made: %d" % res["moves_made"])
	print("  - Waits Made: %d" % res["waits_made"])
	print("  - Enemies Killed: %d" % res["kills"])
	print("  - Total Damage Dealt: %d" % res["dmg_dealt"])
	print("  - Total Damage Taken: %d" % res["dmg_taken"])
	print("  - Pursuit Damage Taken: %d" % res["pursuit_taken"])
	print("  - Telegraphs Evaded: %d" % res["telegraphs_evaded"])
	print("  - Floors Cleared: %d" % res["floors_cleared"])

	if res["outcome"] == "DEFEAT" and not combat.turn_history.is_empty():
		print("\n--- ПОСЛЕДНИЕ ХОДЫ ПЕРЕД ПОРАЖЕНИЕМ (PLAY TELEMETRY) ---")
		for entry in combat.turn_history:
			print("[Ход %d] Действие: %s | HP: %d | Фокус: %d | Преследование: %d | Урон: %s" % [
				entry["turn"], entry["action"], entry["hp"], entry["focus"], entry["pursuit"], entry["dmg_source"]
			])
		print("---------------------------------------------------------")

	print("=====================================\n")

func _manhattan(a: Vector2i, b: Vector2i) -> int:
	return absi(a.x - b.x) + absi(a.y - b.y)

func _is_tile_on_bfs_path(from: Vector2i, to: Vector2i, tile: Vector2i) -> bool:
	if tile == from or tile == to:
		return true
	var queue: Array[Vector2i] = [from]
	var came_from: Dictionary = {}
	came_from[from] = from
	var dirs: Array[Vector2i] = [Vector2i(0, -1), Vector2i(0, 1), Vector2i(-1, 0), Vector2i(1, 0)]
	var found: bool = false

	while not queue.is_empty():
		var current: Vector2i = queue.pop_front()
		if current == to:
			found = true
			break

		for d in dirs:
			var next: Vector2i = current + d
			if dungeon.is_walkable(next) and not came_from.has(next):
				came_from[next] = current
				queue.append(next)

	if not found:
		return false

	var curr: Vector2i = to
	while came_from.has(curr) and came_from[curr] != from:
		if curr == tile:
			return true
		curr = came_from[curr]

	return false

func _resolve_cause(audit: Dictionary) -> String:
	if audit["collected"] == 1:
		return "COLLECTED"
	elif audit["end"] == "DEATH":
		return "DEATH_BEFORE"
	elif audit["p5_fired"] == 1 and (audit["end"] == "STAIRS" or audit["end"] == "VICTORY"):
		return "P5_HP"
	elif audit["p1_on_pickup_path"] == 1 and (audit["end"] == "STAIRS" or audit["end"] == "VICTORY"):
		return "P1_STAIRS"
	elif audit["min_altar_dist_seen"] > 27 and (audit["end"] == "STAIRS" or audit["end"] == "VICTORY"):
		return "UNSEEN"
	elif (audit["end"] == "STAIRS" or audit["end"] == "VICTORY") and audit["floor"] != 8:
		return "COMBAT_THEN_EXIT"
	elif audit["floor"] == 8 and (audit["end"] == "STAIRS" or audit["end"] == "VICTORY"):
		return "F8_RUSH"
	else:
		return "OTHER"

func _run_altar_audit(start_seed: int, end_seed: int) -> void:
	var N: int = end_seed - start_seed + 1
	var counts: Dictionary = {
		2: {"COLLECTED": 0, "DEATH_BEFORE": 0, "P5_HP": 0, "P1_STAIRS": 0, "UNSEEN": 0, "COMBAT_THEN_EXIT": 0, "F8_RUSH": 0, "OTHER": 0},
		4: {"COLLECTED": 0, "DEATH_BEFORE": 0, "P5_HP": 0, "P1_STAIRS": 0, "UNSEEN": 0, "COMBAT_THEN_EXIT": 0, "F8_RUSH": 0, "OTHER": 0},
		6: {"COLLECTED": 0, "DEATH_BEFORE": 0, "P5_HP": 0, "P1_STAIRS": 0, "UNSEEN": 0, "COMBAT_THEN_EXIT": 0, "F8_RUSH": 0, "OTHER": 0},
		8: {"COLLECTED": 0, "DEATH_BEFORE": 0, "P5_HP": 0, "P1_STAIRS": 0, "UNSEEN": 0, "COMBAT_THEN_EXIT": 0, "F8_RUSH": 0, "OTHER": 0}
	}
	var presented: Dictionary = {2: 0, 4: 0, 6: 0, 8: 0}
	var floor6_entry_hp_le8: int = 0
	var floor6_p5_fired: int = 0

	var hash9009: String = ""
	var turns9009: int = 0

	autoplayer.audit_active = true

	for s in range(start_seed, end_seed + 1):
		_start_new_game(s)
		var max_safe_turns: int = 1500
		var current_audits: Dictionary = {}
		var active_floor_audit = null
		var last_altars: int = 0

		while game_state.game_status == GameState.GameStatus.ACTIVE and game_state.total_turns < max_safe_turns:
			var cur_floor: int = game_state.current_floor

			if GameState.ALTAR_FLOORS.has(cur_floor) and not current_audits.has(cur_floor):
				var a_pos: Vector2i = dungeon.altars[0] if not dungeon.altars.is_empty() else Vector2i(-1, -1)
				var c_pos: Vector2i = dungeon.chests[0] if not dungeon.chests.is_empty() else Vector2i(-1, -1)
				var on_exit: int = 1 if (a_pos != Vector2i(-1, -1) and _is_tile_on_bfs_path(dungeon.entrance_pos, dungeon.exit_pos, a_pos)) else 0
				var a_dist: int = _manhattan(dungeon.entrance_pos, a_pos) if a_pos != Vector2i(-1, -1) else -1
				var c_dist: int = _manhattan(dungeon.entrance_pos, c_pos) if c_pos != Vector2i(-1, -1) else -1

				active_floor_audit = {
					"seed": s,
					"floor": cur_floor,
					"entry_hp": player.hp,
					"end_hp": player.hp,
					"min_hp": player.hp,
					"altar_pos": a_pos,
					"chest_pos": c_pos,
					"altar_dist_entry": a_dist,
					"chest_dist_entry": c_dist,
					"altar_on_exit_path": on_exit,
					"collected": 0,
					"end": "STAIRS",
					"p5_fired": 0,
					"p5_first_hp": -1,
					"p1_on_pickup_path": 0,
					"p1_landing_on_pickup": 0,
					"min_altar_dist_seen": _manhattan(player.pos, a_pos) if a_pos != Vector2i(-1, -1) else 999,
					"was_pickup_targeted": false,
					"cause": ""
				}
				current_audits[cur_floor] = active_floor_audit
				presented[cur_floor] += 1

			if active_floor_audit != null and active_floor_audit["floor"] == cur_floor:
				var dist_now: int = _manhattan(player.pos, active_floor_audit["altar_pos"]) if active_floor_audit["altar_pos"] != Vector2i(-1, -1) else 999
				active_floor_audit["min_altar_dist_seen"] = mini(active_floor_audit["min_altar_dist_seen"], dist_now)
				if active_floor_audit["collected"] == 0:
					active_floor_audit["min_hp"] = mini(active_floor_audit["min_hp"], player.hp)

			var hp_before: int = player.hp
			var turn_before: int = game_state.total_turns
			autoplayer.audit_p5_hp_fired_this_turn = false
			autoplayer.audit_pickup_targeted_this_turn = false

			if player.pos == dungeon.exit_pos and active_floor_audit != null and active_floor_audit["floor"] == cur_floor:
				active_floor_audit["end_hp"] = player.hp
				active_floor_audit["p1_on_pickup_path"] = active_floor_audit["p1_landing_on_pickup"]
				active_floor_audit["end"] = "VICTORY" if cur_floor == GameState.MAX_FLOORS else "STAIRS"

			autoplayer.decide_and_act()

			if game_state.total_turns == turn_before and game_state.game_status == GameState.GameStatus.ACTIVE:
				combat.execute_player_wait()

			if active_floor_audit != null and active_floor_audit["floor"] == cur_floor:
				if autoplayer.audit_p5_hp_fired_this_turn and active_floor_audit["collected"] == 0:
					if active_floor_audit["p5_fired"] == 0:
						active_floor_audit["p5_fired"] = 1
						active_floor_audit["p5_first_hp"] = hp_before
				if autoplayer.audit_pickup_targeted_this_turn:
					active_floor_audit["was_pickup_targeted"] = true

				if player.pos == dungeon.exit_pos:
					active_floor_audit["p1_landing_on_pickup"] = 1 if autoplayer.audit_pickup_targeted_this_turn else 0
				else:
					active_floor_audit["p1_landing_on_pickup"] = 0

				var cur_altars: int = game_state.counters["altars_visited"]
				if cur_altars > last_altars:
					active_floor_audit["collected"] = 1
					last_altars = cur_altars

				if game_state.game_status == GameState.GameStatus.DEFEAT:
					active_floor_audit["end"] = "DEATH"
					active_floor_audit["end_hp"] = 0

		for af in GameState.ALTAR_FLOORS:
			if current_audits.has(af):
				var rec = current_audits[af]
				rec["cause"] = _resolve_cause(rec)
				counts[af][rec["cause"]] += 1

				if af == 6:
					if rec["entry_hp"] <= 8:
						floor6_entry_hp_le8 += 1
					if rec["p5_fired"] == 1:
						floor6_p5_fired += 1

				print("ALTAR seed=%d floor=%d collected=%d end=%s entry_hp=%d end_hp=%d min_hp=%d p5_fired=%d p5_first_hp=%d p1_on_pickup_path=%d altar_dist_entry=%d chest_dist_entry=%d altar_on_exit_path=%d cause=%s" % [
					rec["seed"], rec["floor"], rec["collected"], rec["end"],
					rec["entry_hp"], rec["end_hp"], rec["min_hp"],
					rec["p5_fired"], rec["p5_first_hp"], rec["p1_on_pickup_path"],
					rec["altar_dist_entry"], rec["chest_dist_entry"], rec["altar_on_exit_path"],
					rec["cause"]
				])

		if s == 9009:
			hash9009 = "%08X" % (game_state.state_hash & 0xFFFFFFFF)
			turns9009 = game_state.total_turns

	autoplayer.audit_active = false

	if hash9009 == "":
		var res9009: Dictionary = _simulate_autoplay(9009)
		hash9009 = res9009["state_hash"]
		turns9009 = res9009["turns"]

	var slice246_presented: int = presented[2] + presented[4] + presented[6]
	var slice246_collected: int = counts[2]["COLLECTED"] + counts[4]["COLLECTED"] + counts[6]["COLLECTED"]
	var slice246_rate: float = float(slice246_collected) / float(slice246_presented) * 100.0 if slice246_presented > 0 else 0.0

	print("\nAUDIT seed_range=%d-%d n=%d hash9009=%s turns9009=%d" % [start_seed, end_seed, N, hash9009, turns9009])
	for f in [2, 4, 6, 8]:
		print("TABLE floor=%d COLLECTED=%d DEATH_BEFORE=%d P5_HP=%d P1_STAIRS=%d UNSEEN=%d COMBAT_THEN_EXIT=%d F8_RUSH=%d OTHER=%d presented=%d" % [
			f, counts[f]["COLLECTED"], counts[f]["DEATH_BEFORE"], counts[f]["P5_HP"], counts[f]["P1_STAIRS"],
			counts[f]["UNSEEN"], counts[f]["COMBAT_THEN_EXIT"], counts[f]["F8_RUSH"], counts[f]["OTHER"],
			presented[f]
		])
	print("FLOOR6 presented=%d collected=%d death_before=%d p5_hp=%d p1_stairs=%d unseen=%d combat_then_exit=%d other=%d" % [
		presented[6], counts[6]["COLLECTED"], counts[6]["DEATH_BEFORE"], counts[6]["P5_HP"], counts[6]["P1_STAIRS"],
		counts[6]["UNSEEN"], counts[6]["COMBAT_THEN_EXIT"], counts[6]["OTHER"]
	])
	print("FLOOR6 entry_hp_le8=%d" % floor6_entry_hp_le8)
	print("FLOOR6 p5_fired=%d" % floor6_p5_fired)
	print("SLICE246 presented=%d collected=%d rate=%.1f%%" % [slice246_presented, slice246_collected, slice246_rate])

func _run_wait_doom_test(seed_val: int) -> void:
	_start_new_game(seed_val)
	dungeon.enemies.clear()
	print("--- ЗАПУСК ТЕСТА БЕЗДЕЙСТВИЯ (ПРЕСЛЕДОВАНИЕ ЭТАЖА) ---")
	while game_state.game_status == GameState.GameStatus.ACTIVE:
		combat.execute_player_wait()

	var expected_turns: int = (GameState.PURSUIT_MAX_PER_FLOOR / GameState.PURSUIT_COST_WAIT) + int(ceili(float(GameState.PLAYER_MAX_HP) / float(GameState.PURSUIT_DAMAGE_PER_TURN)))
	print("ИТОГ ТЕСТА БЕЗДЕЙСТВИЯ:")
	print("Ходов до гибели: %d (Ожидалось SYS: %d ходов при HP %d и уроне %d)" % [game_state.total_turns, expected_turns, GameState.PLAYER_MAX_HP, GameState.PURSUIT_DAMAGE_PER_TURN])
	print("Причина завершения: %s" % game_state.finish_reason)
	print("Урон от преследования: %d" % game_state.counters["pursuit_damage_taken"])
	print("SYS ВАЛИДАЦИЯ: %s" % ("PASS (Ровно %d ходов)" % expected_turns if game_state.total_turns == expected_turns else "FAIL"))

func _run_determinism_test(seed_val: int) -> void:
	print("--- ЗАПУСК ТЕСТА ДЕТЕРМИНИЗМА (2 ПРОГОНА С ПОЛНЫМ ХЕШЕМ СОСТОЯНИЯ) ---")
	var result1: Dictionary = _simulate_autoplay(seed_val)
	var result2: Dictionary = _simulate_autoplay(seed_val)

	print("ПРОГОН 1: Hash %s, Floor %d, Turns %d, Outcome: %s, HP: %d, Kills: %d, DmgDealt: %d" % [
		result1["state_hash"], result1["floor"], result1["turns"], result1["outcome"], result1["hp"], result1["kills"], result1["dmg_dealt"]
	])
	print("ПРОГОН 2: Hash %s, Floor %d, Turns %d, Outcome: %s, HP: %d, Kills: %d, DmgDealt: %d" % [
		result2["state_hash"], result2["floor"], result2["turns"], result2["outcome"], result2["hp"], result2["kills"], result2["dmg_dealt"]
	])

	var matched: bool = (result1 == result2 and result1["state_hash"] == result2["state_hash"])
	print("СТАТУС ДЕТЕРМИНИЗМА (D-003): %s" % ("PASS (Побитово идентичны, State Hash совпал)" if matched else "FAIL"))

func _run_victory_test(seed_val: int) -> void:
	print("--- ЗАПУСК ВАЛИДАЦИИ ПОЛНОГО ЦИКЛА (8 ЭТАЖЕЙ ДО ПОБЕДЫ) ---")
	var res: Dictionary = _simulate_autoplay(seed_val)
	_print_summary(res)
	print("РЕЗУЛЬТАТ ВАЛИДАЦИИ ПОЛНОГО ПРОХОЖДЕНИЯ: %s (Этажей пройдено: %d/8)" % [res["outcome"], res["floors_cleared"]])

func _run_autoplay_simulation(seed_val: int) -> void:
	var res: Dictionary = _simulate_autoplay(seed_val)
	_print_summary(res)

func _simulate_autoplay(seed_val: int) -> Dictionary:
	_start_new_game(seed_val)
	var max_safe_turns: int = 1500
	var altars_by_floor: Dictionary = {2: 0, 4: 0, 6: 0, 8: 0}
	var last_altars: int = 0

	while game_state.game_status == GameState.GameStatus.ACTIVE and game_state.total_turns < max_safe_turns:
		var floor_before: int = game_state.current_floor
		var turn_before: int = game_state.total_turns
		autoplayer.decide_and_act()
		if game_state.total_turns == turn_before and game_state.game_status == GameState.GameStatus.ACTIVE:
			combat.execute_player_wait()

		var cur_altars: int = game_state.counters["altars_visited"]
		if cur_altars > last_altars:
			altars_by_floor[floor_before] = altars_by_floor.get(floor_before, 0) + (cur_altars - last_altars)
			last_altars = cur_altars

	var spent_total: int = game_state.counters["focus_spent_dash"] + game_state.counters["focus_spent_block"] + game_state.counters["focus_spent_crush"]
	var hex_hash: String = "%08X" % (game_state.state_hash & 0xFFFFFFFF)

	return {
		"seed": seed_val,
		"state_hash": hex_hash,
		"floor": game_state.current_floor,
		"turns": game_state.total_turns,
		"outcome": "VICTORY" if game_state.game_status == GameState.GameStatus.VICTORY else ("DEFEAT" if game_state.game_status == GameState.GameStatus.DEFEAT else "ACTIVE"),
		"reason": game_state.finish_reason,
		"hp": player.hp,
		"focus": player.focus,
		"focus_gained": game_state.counters["focus_gained"],
		"focus_gained_kills": game_state.counters["focus_gained_kills"],
		"focus_gained_altars": game_state.counters["focus_gained_altars"],
		"focus_gained_chests": game_state.counters["focus_gained_chests"],
		"focus_spent_total": spent_total,
		"focus_spent_dash": game_state.counters["focus_spent_dash"],
		"focus_spent_block": game_state.counters["focus_spent_block"],
		"focus_spent_crush": game_state.counters["focus_spent_crush"],
		"dash_used": game_state.counters["dash_used"],
		"block_used": game_state.counters["block_used"],
		"crush_used": game_state.counters["crush_used"],
		"basic_attacks": game_state.counters["basic_attacks"],
		"moves_made": game_state.counters["moves_made"],
		"waits_made": game_state.counters["waits_made"],
		"kills": game_state.counters["enemies_killed"],
		"dmg_dealt": game_state.counters["damage_dealt"],
		"dmg_taken": game_state.counters["damage_taken"],
		"pursuit_taken": game_state.counters["pursuit_damage_taken"],
		"floors_cleared": game_state.counters["floors_cleared"],
		"altars_visited": game_state.counters["altars_visited"],
		"chests_visited": game_state.counters["chests_visited"],
		"telegraphs_evaded": game_state.counters["telegraphs_evaded"],
		"altars_by_floor": altars_by_floor
	}

func _run_custom_moves(seed_val: int, moves_str: String) -> void:
	_start_new_game(seed_val)
	var moves: PackedStringArray = moves_str.split(",")

	for m in moves:
		if game_state.game_status != GameState.GameStatus.ACTIVE:
			break
		m = m.strip_edges().to_lower()
		match m:
			"w", "up": combat.execute_player_move(Vector2i(0, -1))
			"s", "down": combat.execute_player_move(Vector2i(0, 1))
			"a", "left": combat.execute_player_move(Vector2i(-1, 0))
			"d", "right": combat.execute_player_move(Vector2i(1, 0))
			"wait", ".": combat.execute_player_wait()
			"stairs", "e": combat.execute_player_use_stairs()
			"block", "2": combat.execute_player_block()
			"dash_w": combat.execute_player_dash(Vector2i(0, -1))
			"dash_s": combat.execute_player_dash(Vector2i(0, 1))
			"dash_a": combat.execute_player_dash(Vector2i(-1, 0))
			"dash_d": combat.execute_player_dash(Vector2i(1, 0))
			"crush_w": combat.execute_player_crush(Vector2i(0, -1))
			"crush_s": combat.execute_player_crush(Vector2i(0, 1))
			"crush_a": combat.execute_player_crush(Vector2i(-1, 0))
			"crush_d": combat.execute_player_crush(Vector2i(1, 0))

	var spent_total: int = game_state.counters["focus_spent_dash"] + game_state.counters["focus_spent_block"] + game_state.counters["focus_spent_crush"]
	var hex_hash: String = "%08X" % (game_state.state_hash & 0xFFFFFFFF)

	var res: Dictionary = {
		"seed": seed_val,
		"state_hash": hex_hash,
		"floor": game_state.current_floor,
		"turns": game_state.total_turns,
		"outcome": "VICTORY" if game_state.game_status == GameState.GameStatus.VICTORY else ("DEFEAT" if game_state.game_status == GameState.GameStatus.DEFEAT else "ACTIVE"),
		"reason": game_state.finish_reason,
		"hp": player.hp,
		"focus": player.focus,
		"focus_gained": game_state.counters["focus_gained"],
		"focus_gained_kills": game_state.counters["focus_gained_kills"],
		"focus_gained_altars": game_state.counters["focus_gained_altars"],
		"focus_gained_chests": game_state.counters["focus_gained_chests"],
		"focus_spent_total": spent_total,
		"focus_spent_dash": game_state.counters["focus_spent_dash"],
		"focus_spent_block": game_state.counters["focus_spent_block"],
		"focus_spent_crush": game_state.counters["focus_spent_crush"],
		"dash_used": game_state.counters["dash_used"],
		"block_used": game_state.counters["block_used"],
		"crush_used": game_state.counters["crush_used"],
		"basic_attacks": game_state.counters["basic_attacks"],
		"moves_made": game_state.counters["moves_made"],
		"waits_made": game_state.counters["waits_made"],
		"kills": game_state.counters["enemies_killed"],
		"dmg_dealt": game_state.counters["damage_dealt"],
		"dmg_taken": game_state.counters["damage_taken"],
		"pursuit_taken": game_state.counters["pursuit_damage_taken"],
		"floors_cleared": game_state.counters["floors_cleared"],
		"altars_visited": game_state.counters["altars_visited"],
		"chests_visited": game_state.counters["chests_visited"],
		"telegraphs_evaded": game_state.counters["telegraphs_evaded"]
	}
	_print_summary(res)

func _print_ascii_map() -> void:
	var min_x: int = dungeon.width
	var max_x: int = 0
	var min_y: int = dungeon.height
	var max_y: int = 0

	for x in range(dungeon.width):
		for y in range(dungeon.height):
			if dungeon.grid[x][y] != DungeonGenerator.TileType.WALL:
				min_x = mini(min_x, x)
				max_x = maxi(max_x, x)
				min_y = mini(min_y, y)
				max_y = maxi(max_y, y)

	min_x = maxi(0, min_x - 1)
	max_x = mini(dungeon.width - 1, max_x + 1)
	min_y = maxi(0, min_y - 1)
	max_y = mini(dungeon.height - 1, max_y + 1)

	for y in range(min_y, max_y + 1):
		var row_str: String = ""
		for x in range(min_x, max_x + 1):
			var pos: Vector2i = Vector2i(x, y)
			if pos == player.pos:
				row_str += "@"
			else:
				var e: Enemy = combat.get_enemy_at(pos)
				if e != null and e.is_alive():
					row_str += e.symbol
				else:
					var tile = dungeon.grid[x][y]
					match tile:
						DungeonGenerator.TileType.WALL: row_str += "#"
						DungeonGenerator.TileType.FLOOR: row_str += "."
						DungeonGenerator.TileType.ENTRANCE: row_str += "<"
						DungeonGenerator.TileType.EXIT: row_str += ">"
						DungeonGenerator.TileType.CHEST: row_str += "$"
						DungeonGenerator.TileType.ALTAR: row_str += "&"
						_: row_str += " "
		print(row_str)

func _print_manual_screen() -> void:
	print("\n------------------------------------------------------------")
	print("Этаж %d/%d | Ход %d" % [game_state.current_floor, GameState.MAX_FLOORS, game_state.total_turns])
	print("HP %d/%d | Фокус %d/%d | Преследование %d/%d" % [
		player.hp, GameState.PLAYER_MAX_HP,
		player.focus, GameState.PLAYER_MAX_FOCUS,
		maxi(0, game_state.pursuit_remaining), GameState.PURSUIT_MAX_PER_FLOOR
	])
	print("")

	if not combat.combat_log.is_empty():
		var recent: Array[String] = combat.combat_log.slice(-4)
		for msg in recent:
			print("  [>] %s" % msg)
		print("")

	_print_ascii_map()

	print("\nВраги:")
	var living_enemies: Array[Enemy] = []
	for e in dungeon.enemies:
		if e.is_alive():
			living_enemies.append(e)

	if living_enemies.is_empty():
		print("  (Все враги на этаже повержены)")
	else:
		for e in living_enemies:
			var intent_str: String = e.intent_desc
			var dist: int = _manhattan(player.pos, e.pos)
			print("  %s %-20s HP %2d/%2d  дист: %2d  намерение: %s" % [
				e.symbol, e.name_ru, e.hp, e.max_hp, dist, intent_str
			])

	print("\nДействия:")
	print("  w a s d      шаг или удар в сторону")
	print("  1 + сторона  Рывок (2Ф) [1w, 1s, 1a, 1d]")
	print("  2            Блок (1Ф)")
	print("  3 + сторона  Сокрушение (2Ф) [3w, 3s, 3a, 3d]")
	print("  . / space    ждать (пропуск хода, -6 Преследования)")
	print("  e            спуститься по лестнице")
	print("  q            выйти из игры")

func _print_manual_help() -> void:
	print("==========================================================================")
	print("  ROGUE-02: ПАМЯТКА ИГРОКА")
	print("  • ЦЕЛЬ: Спуститься и пройти все 8 этажей подземелья.")
	print("  • КАРТА: @ Игрок | > Спуск вниз | $ Тайник (+4 HP, +2Ф) | & Алтарь (+2Ф)")
	print("  • ВРАГИ: S Скелет (8) | A Лучник (10) | G Страж (16) | O Огр (16) | T Тень (12) | M Маг (16)")
	print("  • НАВЫКИ: [1] Рывок (2Ф, 2 клетки сквозь врагов) | [2] Блок (1Ф, 100% защита) | [3] Сокрушение (2Ф, 8 урона + стан)")
	print("  • УПРАВЛЕНИЕ: w/a/s/d (шаг/удар), 1+dir (рывок), 2 (блок), 3+dir (сокрушение), . (ждать), e (спуск)")
	print("==========================================================================")

func _parse_dir(s: String) -> Vector2i:
	match s:
		"w", "up", "k": return Vector2i(0, -1)
		"s", "down", "j": return Vector2i(0, 1)
		"a", "left", "h": return Vector2i(-1, 0)
		"d", "right", "l": return Vector2i(1, 0)
		_: return Vector2i.ZERO

func _execute_manual_command(cmd: String) -> void:
	cmd = cmd.strip_edges().to_lower()
	if cmd == "w" or cmd == "up" or cmd == "k":
		combat.execute_player_move(Vector2i(0, -1))
	elif cmd == "s" or cmd == "down" or cmd == "j":
		combat.execute_player_move(Vector2i(0, 1))
	elif cmd == "a" or cmd == "left" or cmd == "h":
		combat.execute_player_move(Vector2i(-1, 0))
	elif cmd == "d" or cmd == "right" or cmd == "l":
		combat.execute_player_move(Vector2i(1, 0))
	elif cmd == "." or cmd == "wait" or cmd == "space" or cmd == " ":
		combat.execute_player_wait()
	elif cmd == "e" or cmd == "stairs" or cmd == "enter":
		combat.execute_player_use_stairs()
	elif cmd == "2" or cmd == "block":
		combat.execute_player_block()
	elif cmd.begins_with("1") or cmd.begins_with("dash"):
		var dir_str: String = ""
		if cmd.begins_with("1"):
			dir_str = cmd.substr(1).strip_edges()
		elif cmd.begins_with("dash"):
			dir_str = cmd.substr(4).strip_edges().replace("_", "")
		if dir_str == "":
			print("Укажите направление Рывка (w/a/s/d): ")
			dir_str = OS.read_string_from_stdin().strip_edges().to_lower()
		var d: Vector2i = _parse_dir(dir_str)
		if d != Vector2i.ZERO:
			combat.execute_player_dash(d)
		else:
			print("Неизвестное направление для Рывка: '%s'. Используйте w, a, s, d." % dir_str)
	elif cmd.begins_with("3") or cmd.begins_with("crush"):
		var dir_str: String = ""
		if cmd.begins_with("3"):
			dir_str = cmd.substr(1).strip_edges()
		elif cmd.begins_with("crush"):
			dir_str = cmd.substr(5).strip_edges().replace("_", "")
		if dir_str == "":
			print("Укажите направление Сокрушения (w/a/s/d): ")
			dir_str = OS.read_string_from_stdin().strip_edges().to_lower()
		var d: Vector2i = _parse_dir(dir_str)
		if d != Vector2i.ZERO:
			combat.execute_player_crush(d)
		else:
			print("Неизвестное направление для Сокрушения: '%s'. Используйте w, a, s, d." % dir_str)
	else:
		print("Неизвестная команда: '%s'. Введите w, a, s, d, 1+dir, 2, 3+dir, . или e (или 'help')." % cmd)

func _run_manual_mode(seed_val: int) -> void:
	_start_new_game(seed_val)
	print("\n=== ROGUE-02: РЕЖИМ РУЧНОЙ ИГРЫ (SEED: %d) ===" % seed_val)
	_print_manual_help()

	while game_state.game_status == GameState.GameStatus.ACTIVE:
		_print_manual_screen()
		print("\n> ")
		var raw_line: String = OS.read_string_from_stdin()
		if raw_line == "":
			print("Поток ввода завершён (EOF). Завершение игры.")
			break
		var line: String = raw_line.strip_edges().to_lower()
		if line == "":
			continue

		if line == "q" or line == "quit" or line == "exit":
			print("Игра прервана пользователем.")
			return
		elif line == "help" or line == "?":
			_print_manual_help()
			continue

		var turns_before: int = game_state.total_turns
		_execute_manual_command(line)

	_print_manual_screen()
	if game_state.game_status == GameState.GameStatus.VICTORY:
		print("\n==============================================")
		print("  ПОБЕДА! ВЫ УСПЕШНО ПРОШЛИ ВСЕ 8 ЭТАЖЕЙ!  ")
		print("==============================================")
	else:
		print("\n==============================================")
		print("  ПОРАЖЕНИЕ: ВЫ ПОГИБЛИ В ПОДЗЕМЕЛЬЕ...  ")
		print("  Причина: %s" % game_state.finish_reason)
		print("==============================================")

	var res: Dictionary = {
		"seed": seed_val,
		"state_hash": "%08X" % (game_state.state_hash & 0xFFFFFFFF),
		"floor": game_state.current_floor,
		"turns": game_state.total_turns,
		"outcome": "VICTORY" if game_state.game_status == GameState.GameStatus.VICTORY else "DEFEAT",
		"reason": game_state.finish_reason,
		"hp": player.hp,
		"focus": player.focus,
		"focus_gained": game_state.counters["focus_gained"],
		"focus_gained_kills": game_state.counters["focus_gained_kills"],
		"focus_gained_altars": game_state.counters["focus_gained_altars"],
		"focus_gained_chests": game_state.counters["focus_gained_chests"],
		"focus_spent_total": game_state.counters["focus_spent_dash"] + game_state.counters["focus_spent_block"] + game_state.counters["focus_spent_crush"],
		"focus_spent_dash": game_state.counters["focus_spent_dash"],
		"focus_spent_block": game_state.counters["focus_spent_block"],
		"focus_spent_crush": game_state.counters["focus_spent_crush"],
		"dash_used": game_state.counters["dash_used"],
		"block_used": game_state.counters["block_used"],
		"crush_used": game_state.counters["crush_used"],
		"basic_attacks": game_state.counters["basic_attacks"],
		"moves_made": game_state.counters["moves_made"],
		"waits_made": game_state.counters["waits_made"],
		"kills": game_state.counters["enemies_killed"],
		"dmg_dealt": game_state.counters["damage_dealt"],
		"dmg_taken": game_state.counters["damage_taken"],
		"pursuit_taken": game_state.counters["pursuit_damage_taken"],
		"floors_cleared": game_state.counters["floors_cleared"],
		"altars_visited": game_state.counters["altars_visited"],
		"chests_visited": game_state.counters["chests_visited"],
		"telegraphs_evaded": game_state.counters["telegraphs_evaded"]
	}
	_print_summary(res)

func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey) or not event.is_pressed() or event.is_echo():
		return

	if game_state.game_status != GameState.GameStatus.ACTIVE:
		if event.keycode == KEY_R or event.keycode == KEY_ENTER:
			_start_new_game(game_state.current_seed + 1)
		return

	var key: Key = event.keycode
	var move_dir: Vector2i = Vector2i.ZERO

	if key == KEY_W or key == KEY_UP: move_dir = Vector2i(0, -1)
	elif key == KEY_S or key == KEY_DOWN: move_dir = Vector2i(0, 1)
	elif key == KEY_A or key == KEY_LEFT: move_dir = Vector2i(-1, 0)
	elif key == KEY_D or key == KEY_RIGHT: move_dir = Vector2i(1, 0)

	if target_mode == "DASH":
		if move_dir != Vector2i.ZERO:
			target_mode = ""
			combat.execute_player_dash(move_dir)
			queue_redraw()
		elif key == KEY_ESCAPE:
			target_mode = ""
			combat.log_message("Рывок отменён.")
			queue_redraw()
		return

	if target_mode == "CRUSH":
		if move_dir != Vector2i.ZERO:
			target_mode = ""
			combat.execute_player_crush(move_dir)
			queue_redraw()
		elif key == KEY_ESCAPE:
			target_mode = ""
			combat.log_message("Сокрушение отменено.")
			queue_redraw()
		return

	if move_dir != Vector2i.ZERO:
		combat.execute_player_move(move_dir)
		queue_redraw()
		return

	if key == KEY_1:
		if player.can_afford(GameState.COST_DASH):
			target_mode = "DASH"
			combat.log_message("РЫВОК: выберите направление стрелками/WASD (Esc - отмена)...")
		else:
			combat.log_message("Недостаточно Фокуса для Рывка (нужно 2)!")
		queue_redraw()
		return

	if key == KEY_2:
		combat.execute_player_block()
		queue_redraw()
		return

	if key == KEY_3:
		if player.can_afford(GameState.COST_CRUSH):
			target_mode = "CRUSH"
			combat.log_message("СОКРУШЕНИЕ: укажите направление на врага стрелками/WASD...")
		else:
			combat.log_message("Недостаточно Фокуса для Сокрушения (нужно 2)!")
		queue_redraw()
		return

	if key == KEY_SPACE or key == KEY_PERIOD:
		combat.execute_player_wait()
		queue_redraw()
		return

	if key == KEY_E or key == KEY_ENTER:
		combat.execute_player_use_stairs()
		queue_redraw()
		return

	if key == KEY_R:
		_start_new_game(game_state.current_seed)
		queue_redraw()
		return

func _draw() -> void:
	draw_rect(Rect2(0, 0, 1280, 720), Color("#10131C"))

	if dungeon == null or dungeon.grid.is_empty():
		return

	for x in range(dungeon.width):
		for y in range(dungeon.height):
			var tile: DungeonGenerator.TileType = dungeon.grid[x][y]
			var rect: Rect2 = Rect2(origin_x + x * cell_size, origin_y + y * cell_size, cell_size - 1, cell_size - 1)
			match tile:
				DungeonGenerator.TileType.WALL:
					draw_rect(rect, Color("#2B3044"))
				DungeonGenerator.TileType.FLOOR:
					draw_rect(rect, Color("#181D2B"))
				DungeonGenerator.TileType.ENTRANCE:
					draw_rect(rect, Color("#18303B"))
					draw_string(ThemeDB.fallback_font, rect.position + Vector2(4, 13), "<", HORIZONTAL_ALIGNMENT_CENTER, -1, 12, Color("#66E6FF"))
				DungeonGenerator.TileType.EXIT:
					draw_rect(rect, Color("#38321B"))
					draw_string(ThemeDB.fallback_font, rect.position + Vector2(4, 13), ">", HORIZONTAL_ALIGNMENT_CENTER, -1, 12, Color("#FFD978"))
				DungeonGenerator.TileType.CHEST:
					draw_rect(rect, Color("#38251B"))
					draw_string(ThemeDB.fallback_font, rect.position + Vector2(4, 13), "$", HORIZONTAL_ALIGNMENT_CENTER, -1, 12, Color("#FFD978"))
				DungeonGenerator.TileType.ALTAR:
					draw_rect(rect, Color("#251C38"))
					draw_string(ThemeDB.fallback_font, rect.position + Vector2(4, 13), "&", HORIZONTAL_ALIGNMENT_CENTER, -1, 12, Color("#B7A8FF"))

	for e in dungeon.enemies:
		if e.is_alive() and e.charge_turns > 0:
			if e.intent_type == Enemy.IntentType.SLAM:
				var tpos: Vector2i = e.intent_target
				var r: Rect2 = Rect2(origin_x + tpos.x * cell_size, origin_y + tpos.y * cell_size, cell_size - 1, cell_size - 1)
				draw_rect(r, Color(1.0, 0.2, 0.2, 0.45))
			elif e.intent_type == Enemy.IntentType.AOE_DETONATE:
				var center: Vector2i = e.intent_target
				for ax in range(center.x - 1, center.x + 2):
					for ay in range(center.y - 1, center.y + 2):
						if ax >= 0 and ax < dungeon.width and ay >= 0 and ay < dungeon.height:
							var r: Rect2 = Rect2(origin_x + ax * cell_size, origin_y + ay * cell_size, cell_size - 1, cell_size - 1)
							draw_rect(r, Color(1.0, 0.4, 0.1, 0.35))

	for e in dungeon.enemies:
		if e.is_alive():
			var rect: Rect2 = Rect2(origin_x + e.pos.x * cell_size, origin_y + e.pos.y * cell_size, cell_size - 1, cell_size - 1)
			draw_rect(rect, Color(e.color_hex))
			draw_string(ThemeDB.fallback_font, rect.position + Vector2(4, 13), e.symbol, HORIZONTAL_ALIGNMENT_CENTER, -1, 12, Color("#10131C"))

			var hp_ratio: float = float(e.hp) / float(e.max_hp)
			draw_rect(Rect2(rect.position.x, rect.position.y - 3, cell_size - 1, 2), Color("#333333"))
			draw_rect(Rect2(rect.position.x, rect.position.y - 3, (cell_size - 1) * hp_ratio, 2), Color("#FF6B7A"))

	var p_rect: Rect2 = Rect2(origin_x + player.pos.x * cell_size, origin_y + player.pos.y * cell_size, cell_size - 1, cell_size - 1)
	draw_rect(p_rect, Color("#66E6FF"))
	draw_string(ThemeDB.fallback_font, p_rect.position + Vector2(3, 13), "@", HORIZONTAL_ALIGNMENT_CENTER, -1, 13, Color("#10131C"))

	draw_rect(Rect2(0, 0, 1280, 72), Color("#161A26"))
	draw_line(Vector2(0, 72), Vector2(1280, 72), Color("#65708A"), 1.0)

	draw_string(ThemeDB.fallback_font, Vector2(24, 30), "ЭТАЖ: %d / %d" % [game_state.current_floor, GameState.MAX_FLOORS], HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#E8ECF4"))
	draw_string(ThemeDB.fallback_font, Vector2(24, 54), "ХОД: %d   (СИД: %d)" % [game_state.total_turns, game_state.current_seed], HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("#8993A7"))

	var hp_color: Color = Color("#66E6FF") if player.hp > 8 else Color("#FF6B7A")
	draw_string(ThemeDB.fallback_font, Vector2(260, 30), "ЗДОРОВЬЕ: %d / %d" % [player.hp, player.max_hp], HORIZONTAL_ALIGNMENT_LEFT, -1, 16, hp_color)
	draw_rect(Rect2(260, 38, 180, 10), Color("#222838"))
	draw_rect(Rect2(260, 38, 180 * (float(player.hp) / float(player.max_hp)), 10), hp_color)

	var focus_text: String = ""
	for f in range(player.max_focus):
		focus_text += "◆ " if f < player.focus else "◇ "
	draw_string(ThemeDB.fallback_font, Vector2(470, 30), "ФОКУС: %s(%d/%d)" % [focus_text, player.focus, player.max_focus], HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color("#FFD978"))
	draw_string(ThemeDB.fallback_font, Vector2(470, 52), "+1 за убийство, +2 алтарь/тайник", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("#8993A7"))

	var pursuit_color: Color = Color("#77D9F0")
	if game_state.pursuit_remaining <= 30:
		pursuit_color = Color("#FF6B7A")
	elif game_state.pursuit_remaining <= 60:
		pursuit_color = Color("#FFD978")

	draw_string(ThemeDB.fallback_font, Vector2(740, 30), "ПРЕСЛЕДОВАНИЕ: %d / 120" % maxi(0, game_state.pursuit_remaining), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, pursuit_color)
	draw_rect(Rect2(740, 38, 180, 10), Color("#222838"))
	draw_rect(Rect2(740, 38, 180 * (clampf(float(game_state.pursuit_remaining) / 120.0, 0.0, 1.0)), 10), pursuit_color)
	draw_string(ThemeDB.fallback_font, Vector2(740, 58), "Ход -1, Пропуск -6. Скверна при 0!", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color("#8993A7"))

	draw_string(ThemeDB.fallback_font, Vector2(960, 24), "[1] Рывок (2Ф)   [2] Блок (1Ф)", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#66E6FF"))
	draw_string(ThemeDB.fallback_font, Vector2(960, 42), "[3] Сокрушение (2Ф) [Space] Ждать", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#66E6FF"))
	draw_string(ThemeDB.fallback_font, Vector2(960, 60), "[WASD] Перемещение/Удар [E] Лестница", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("#E8ECF4"))

	var sb_x: int = 860
	draw_rect(Rect2(sb_x, origin_y, 400, 600), Color("#141722"))
	draw_line(Vector2(sb_x, origin_y), Vector2(sb_x, origin_y + 600), Color("#404B69"), 1.0)

	draw_string(ThemeDB.fallback_font, Vector2(sb_x + 16, origin_y + 24), "НАМЕРЕНИЯ ВРАГОВ НА СЛЕДУЮЩИЙ ХОД:", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("#FFD978"))

	var line_y: int = origin_y + 50
	var living_count: int = 0
	for e in dungeon.enemies:
		if e.is_alive():
			living_count += 1
			var info: String = "[%s] %s: %s (HP %d/%d)" % [e.symbol, e.name_ru, e.intent_desc, e.hp, e.max_hp]
			draw_string(ThemeDB.fallback_font, Vector2(sb_x + 16, line_y), info, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(e.color_hex))
			line_y += 24
			if line_y > origin_y + 280:
				break

	if living_count == 0:
		draw_string(ThemeDB.fallback_font, Vector2(sb_x + 16, line_y), "Все враги на этаже зачищены!", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#8CE870"))

	var log_y: int = origin_y + 320
	draw_line(Vector2(sb_x + 10, log_y - 15), Vector2(sb_x + 390, log_y - 15), Color("#404B69"), 1.0)
	draw_string(ThemeDB.fallback_font, Vector2(sb_x + 16, log_y), "ЖУРНАЛ СОБЫТИЙ:", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("#E8ECF4"))

	var entry_y: int = log_y + 24
	var logs_to_show: Array[String] = combat.combat_log.slice(-10)
	for msg in logs_to_show:
		draw_string(ThemeDB.fallback_font, Vector2(sb_x + 16, entry_y), msg, HORIZONTAL_ALIGNMENT_LEFT, 370, 11, Color("#CCD2E0"))
		entry_y += 22

	if game_state.game_status != GameState.GameStatus.ACTIVE:
		draw_rect(Rect2(200, 200, 880, 320), Color(0.06, 0.08, 0.12, 0.92))
		draw_rect(Rect2(200, 200, 880, 320), Color("#65708A"), false, 2.0)

		var title_col: Color = Color("#FFD978") if game_state.game_status == GameState.GameStatus.VICTORY else Color("#FF6B7A")
		var title_txt: String = "ПОБЕДА! СПУСК ЗАВЕРШЁН" if game_state.game_status == GameState.GameStatus.VICTORY else "ПОРАЖЕНИЕ: СМЕРТЬ В ПОДЗЕМЕЛЬЕ"
		draw_string(ThemeDB.fallback_font, Vector2(240, 260), title_txt, HORIZONTAL_ALIGNMENT_CENTER, 800, 24, title_col)
		draw_string(ThemeDB.fallback_font, Vector2(240, 300), game_state.finish_reason, HORIZONTAL_ALIGNMENT_CENTER, 800, 15, Color("#E8ECF4"))

		var stat_str: String = "Ходов: %d   Убито врагов: %d   Нанесено урона: %d   Получено урона: %d" % [
			game_state.total_turns, game_state.counters["enemies_killed"], game_state.counters["damage_dealt"], game_state.counters["damage_taken"]
		]
		draw_string(ThemeDB.fallback_font, Vector2(240, 350), stat_str, HORIZONTAL_ALIGNMENT_CENTER, 800, 13, Color("#8993A7"))

		var skills_str: String = "Применения: Рывок %d | Блок %d | Сокрушение %d | Набрано фокуса: %d" % [
			game_state.counters["dash_used"], game_state.counters["block_used"], game_state.counters["crush_used"], game_state.counters["focus_gained"]
		]
		draw_string(ThemeDB.fallback_font, Vector2(240, 380), skills_str, HORIZONTAL_ALIGNMENT_CENTER, 800, 13, Color("#8993A7"))

		draw_string(ThemeDB.fallback_font, Vector2(240, 450), "Нажмите [ENTER] или [R] для нового спуска", HORIZONTAL_ALIGNMENT_CENTER, 800, 16, Color("#66E6FF"))


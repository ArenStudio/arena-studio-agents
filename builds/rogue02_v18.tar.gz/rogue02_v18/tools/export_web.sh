#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
OUTPUT_DIR="$PROJECT_DIR/build/web"

echo "=== ROGUE-02: HTML5 (WEB) EXPORT PIPELINE ==="

# 1. Locate Godot binary
GODOT_BIN=""
if [ -f "/home/user/godot_bin" ]; then
    chmod +x "/home/user/godot_bin" 2>/dev/null || true
    GODOT_BIN="/home/user/godot_bin"
elif command -v godot &> /dev/null; then
    GODOT_BIN="$(command -v godot)"
fi

if [ -z "$GODOT_BIN" ]; then
    echo "ОШИБКА: Исполняемый файл Godot не найден!"
    echo "Убедитесь, что бинарник доступен по пути /home/user/godot_bin или в PATH."
    exit 1
fi

echo "Используется Godot: $GODOT_BIN"

# 2. Check for export templates
GODOT_VERSION="$("$GODOT_BIN" --version 2>/dev/null | head -n 1 | awk '{print $1}')"
SHORT_VERSION="$(echo "$GODOT_VERSION" | cut -d. -f1-2).stable"

TEMPLATE_DIR="$HOME/.local/share/godot/export_templates/$GODOT_VERSION"
if [ ! -d "$TEMPLATE_DIR" ] && [ -d "$HOME/.local/share/godot/export_templates/$SHORT_VERSION" ]; then
    TEMPLATE_DIR="$HOME/.local/share/godot/export_templates/$SHORT_VERSION"
fi

WEB_RELEASE_ZIP="$TEMPLATE_DIR/web_release.zip"
WEB_DEBUG_ZIP="$TEMPLATE_DIR/web_debug.zip"

if [ ! -f "$WEB_RELEASE_ZIP" ] && [ ! -f "$TEMPLATE_DIR/web_nothreads_release.zip" ]; then
    echo ""
    echo "========================================================================="
    echo "ВНИМАНИЕ: Экспортные шаблоны для Web не установлены!"
    echo "Путь поиска: $HOME/.local/share/godot/export_templates/4.3.stable"
    echo ""
    echo "ИНСТРУКЦИЯ ПО УСТАНОВКЕ ШАБЛОНОВ:"
    echo "1. Скачайте официальный архив шаблонов Godot export templates:"
    echo "   URL: https://github.com/godotengine/godot/releases/download/4.3-stable/Godot_v4.3-stable_export_templates.tpz"
    echo "2. Распакуйте содержимое папки templates/ в целевую директорию:"
    echo "   mkdir -p \"$HOME/.local/share/godot/export_templates/4.3.stable\""
    echo "   unzip Godot_v4.3-stable_export_templates.tpz -d /tmp/tpz_unpack"
    echo "   cp -r /tmp/tpz_unpack/templates/* \"$HOME/.local/share/godot/export_templates/4.3.stable/\""
    echo "   rm -rf /tmp/tpz_unpack"
    echo "3. Повторите запуск $0"
    echo "========================================================================="
    exit 1
fi

# 3. Perform Export
mkdir -p "$OUTPUT_DIR"
echo "Сборка Web-релиза в $OUTPUT_DIR..."

"$GODOT_BIN" --headless --path "$PROJECT_DIR" --export-release "Web" "$OUTPUT_DIR/index.html"

echo ""
echo "=== ЭКСПОРТ УСПЕШНО ЗАВЕРШЁН ==="
echo "Сгенерированные файлы:"
ls -lh "$OUTPUT_DIR"

# КОНЕЦ ФАЙЛА tools/export_web.sh
